import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';
import type { Request, Response } from 'express';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);

function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured in the server environment.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function getAqiLabel(aqi: number | null): string {
  if (aqi === null || Number.isNaN(aqi)) return 'Unavailable';
  if (aqi <= 50) return 'Good';
  if (aqi <= 100) return 'Moderate';
  if (aqi <= 150) return 'Sensitive Groups';
  if (aqi <= 200) return 'Unhealthy';
  return 'Very Unhealthy';
}

const app = express();
app.use(express.json({ limit: '1mb' }));

// Live Geocoding via Open-Meteo
app.get('/api/geocode', async (req: Request, res: Response) => {
  try {
    const query = String(req.query.q || '').trim();
    if (query.length < 2) {
      res.json({ results: [] });
      return;
    }

    const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(query)}&count=8&language=en&format=json`;
    const upstream = await fetch(url);
    if (!upstream.ok) {
      res.status(502).json({ error: `Geocoding service returned ${upstream.status}` });
      return;
    }
    const data = (await upstream.json()) as {
      results?: Array<{
        id: number;
        name: string;
        admin1?: string;
        country?: string;
        latitude: number;
        longitude: number;
        elevation?: number;
        timezone?: string;
      }>;
    };

    const results = (data.results || []).map((item) => ({
      id: `${item.id}`,
      name: item.name,
      region: item.admin1 || '',
      country: item.country || '',
      latitude: item.latitude,
      longitude: item.longitude,
      elevation: item.elevation,
      timezone: item.timezone || 'auto',
    }));

    res.json({ results });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Failed to search destinations';
    res.status(500).json({ error: message });
  }
});

// Live Meteorological Telemetry + Air Quality via Open-Meteo
app.get('/api/weather', async (req: Request, res: Response) => {
  try {
    const lat = Number(req.query.lat);
    const lon = Number(req.query.lon);
    const name = String(req.query.name || 'Selected Destination');
    const country = String(req.query.country || '');
    const region = String(req.query.region || '');
    const id = String(req.query.id || `${lat.toFixed(2)}_${lon.toFixed(2)}`);
    const elevation = req.query.elevation ? Number(req.query.elevation) : undefined;
    const tz = String(req.query.timezone || 'auto');

    if (Number.isNaN(lat) || Number.isNaN(lon)) {
      res.status(400).json({ error: 'Valid latitude and longitude are required.' });
      return;
    }

    const weatherParams = new URLSearchParams({
      latitude: String(lat),
      longitude: String(lon),
      timezone: tz || 'auto',
      forecast_days: '7',
      current: [
        'temperature_2m',
        'relative_humidity_2m',
        'apparent_temperature',
        'is_day',
        'precipitation',
        'weather_code',
        'cloud_cover',
        'surface_pressure',
        'wind_speed_10m',
        'wind_direction_10m',
        'wind_gusts_10m',
      ].join(','),
      hourly: [
        'temperature_2m',
        'relative_humidity_2m',
        'dew_point_2m',
        'apparent_temperature',
        'precipitation_probability',
        'precipitation',
        'weather_code',
        'cloud_cover',
        'visibility',
        'wind_speed_10m',
        'wind_gusts_10m',
        'uv_index',
        'is_day',
      ].join(','),
      daily: [
        'weather_code',
        'temperature_2m_max',
        'temperature_2m_min',
        'apparent_temperature_max',
        'apparent_temperature_min',
        'sunrise',
        'sunset',
        'uv_index_max',
        'precipitation_sum',
        'precipitation_probability_max',
        'wind_speed_10m_max',
      ].join(','),
    });

    const aqiParams = new URLSearchParams({
      latitude: String(lat),
      longitude: String(lon),
      timezone: tz || 'auto',
      current: 'us_aqi,pm2_5,pm10,ozone',
    });

    const [weatherResp, aqiResp] = await Promise.all([
      fetch(`https://api.open-meteo.com/v1/forecast?${weatherParams.toString()}`),
      fetch(`https://air-quality-api.open-meteo.com/v1/air-quality?${aqiParams.toString()}`),
    ]);

    if (!weatherResp.ok) {
      res.status(502).json({ error: `Weather telemetry upstream returned ${weatherResp.status}` });
      return;
    }

    const weatherJson = (await weatherResp.json()) as Record<string, any>;
    const aqiJson = aqiResp.ok ? ((await aqiResp.json()) as Record<string, any>) : null;

    const current = weatherJson.current || {};
    const hourly = weatherJson.hourly || {};
    const daily = weatherJson.daily || {};

    // Find current hour index to slice next 24 hours
    const currentTimeStr = String(current.time || '');
    const currentHourPrefix = currentTimeStr.slice(0, 13);
    const hourlyTimes: string[] = Array.isArray(hourly.time) ? hourly.time : [];
    let startIndex = hourlyTimes.findIndex((t) => t.startsWith(currentHourPrefix));
    if (startIndex < 0) startIndex = 0;

    const next24Hours = hourlyTimes.slice(startIndex, startIndex + 24).map((t, offset) => {
      const idx = startIndex + offset;
      return {
        time: t,
        temperatureC: Number(hourly.temperature_2m?.[idx] ?? 0),
        apparentTemperatureC: Number(hourly.apparent_temperature?.[idx] ?? 0),
        precipitationProbability: Number(hourly.precipitation_probability?.[idx] ?? 0),
        precipitationMm: Number(hourly.precipitation?.[idx] ?? 0),
        weatherCode: Number(hourly.weather_code?.[idx] ?? 0),
        humidity: Number(hourly.relative_humidity_2m?.[idx] ?? 0),
        cloudCover: Number(hourly.cloud_cover?.[idx] ?? 0),
        windSpeedKmh: Number(hourly.wind_speed_10m?.[idx] ?? 0),
        windGustsKmh: Number(hourly.wind_gusts_10m?.[idx] ?? 0),
        uvIndex: Number(hourly.uv_index?.[idx] ?? 0),
        isDay: Boolean(hourly.is_day?.[idx] ?? 1),
      };
    });

    const dailyTimes: string[] = Array.isArray(daily.time) ? daily.time : [];
    const dailyForecast = dailyTimes.map((d, idx) => ({
      date: d,
      weatherCode: Number(daily.weather_code?.[idx] ?? 0),
      tempMaxC: Number(daily.temperature_2m_max?.[idx] ?? 0),
      tempMinC: Number(daily.temperature_2m_min?.[idx] ?? 0),
      apparentMaxC: Number(daily.apparent_temperature_max?.[idx] ?? 0),
      apparentMinC: Number(daily.apparent_temperature_min?.[idx] ?? 0),
      sunrise: String(daily.sunrise?.[idx] ?? ''),
      sunset: String(daily.sunset?.[idx] ?? ''),
      precipitationSumMm: Number(daily.precipitation_sum?.[idx] ?? 0),
      precipitationProbabilityMax: Number(daily.precipitation_probability_max?.[idx] ?? 0),
      windSpeedMaxKmh: Number(daily.wind_speed_10m_max?.[idx] ?? 0),
      uvIndexMax: Number(daily.uv_index_max?.[idx] ?? 0),
    }));

    const currentVisibilityMeters = Number(hourly.visibility?.[startIndex] ?? 10000);
    const currentDewPointC = Number(hourly.dew_point_2m?.[startIndex] ?? 0);
    const currentUvIndex = Number(hourly.uv_index?.[startIndex] ?? 0);

    const aqiCurrent = aqiJson?.current || {};
    const usAqi = typeof aqiCurrent.us_aqi === 'number' ? aqiCurrent.us_aqi : null;

    res.json({
      destination: {
        id,
        name,
        region,
        country,
        latitude: lat,
        longitude: lon,
        elevation: elevation ?? weatherJson.elevation,
        timezone: weatherJson.timezone || tz,
      },
      utcOffsetSeconds: Number(weatherJson.utc_offset_seconds ?? 0),
      current: {
        time: currentTimeStr,
        temperatureC: Number(current.temperature_2m ?? 0),
        apparentTemperatureC: Number(current.apparent_temperature ?? 0),
        humidity: Number(current.relative_humidity_2m ?? 0),
        dewPointC: currentDewPointC,
        precipitationMm: Number(current.precipitation ?? 0),
        weatherCode: Number(current.weather_code ?? 0),
        cloudCover: Number(current.cloud_cover ?? 0),
        pressureHpa: Number(current.surface_pressure ?? 1013),
        windSpeedKmh: Number(current.wind_speed_10m ?? 0),
        windDirectionDeg: Number(current.wind_direction_10m ?? 0),
        windGustsKmh: Number(current.wind_gusts_10m ?? 0),
        uvIndex: currentUvIndex,
        visibilityKm: Math.round((currentVisibilityMeters / 1000) * 10) / 10,
        isDay: Boolean(current.is_day ?? 1),
      },
      hourly: next24Hours,
      daily: dailyForecast,
      airQuality: {
        usAqi,
        pm25: typeof aqiCurrent.pm2_5 === 'number' ? aqiCurrent.pm2_5 : null,
        pm10: typeof aqiCurrent.pm10 === 'number' ? aqiCurrent.pm10 : null,
        ozone: typeof aqiCurrent.ozone === 'number' ? aqiCurrent.ozone : null,
        category: getAqiLabel(usAqi),
      },
      fetchedAt: new Date().toISOString(),
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Failed to load atmospheric telemetry';
    res.status(500).json({ error: message });
  }
});

// AI Dynamic Destination Forecast Briefing via Gemini
app.post('/api/ai-forecast', async (req: Request, res: Response) => {
  try {
    const { weather, intent = 'travel', unit = 'C' } = req.body as {
      weather: Record<string, any>;
      intent?: string;
      unit?: string;
    };

    if (!weather || !weather.destination || !weather.current) {
      res.status(400).json({ error: 'Weather payload is required for AI briefing.' });
      return;
    }

    const ai = getGeminiClient();

    const intentLabels: Record<string, string> = {
      travel: 'General travel, sightseeing, and transit logistics',
      photography: 'Outdoor photography, golden hour lighting, sky clarity, and lens protection',
      outdoor: 'Mountain trail trekking, elevation/wind exposure, and hydration/layering',
      commute: 'Daily urban commute, visibility, rain disruption windows, and comfort',
    };

    const intentGoal = intentLabels[intent] || intentLabels.travel;

    const promptContext = {
      destination: weather.destination,
      unitPreference: unit === 'F' ? 'Fahrenheit and mph' : 'Celsius and km/h',
      current: weather.current,
      airQuality: weather.airQuality,
      next12Hours: Array.isArray(weather.hourly) ? weather.hourly.slice(0, 12) : [],
      next3Days: Array.isArray(weather.daily) ? weather.daily.slice(0, 3) : [],
    };

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: `Generate a concise, high-precision meteorological destination briefing for ${weather.destination.name}, ${weather.destination.country}.
Focus specifically on this user intent: ${intentGoal}.
Use ONLY the provided real-time telemetry below and express temperatures/wind in ${promptContext.unitPreference}.
Do not invent numbers not supported by the telemetry.

Telemetry JSON:
${JSON.stringify(promptContext)}`,
      config: {
        systemInstruction:
          'You are VayuMausam AI, a crisp, authoritative meteorologist and travel-weather strategist. Write clear, grounded prose without fluff, emojis, or exclamation marks. Always cite specific hours, temperatures, wind speeds, or visibility when relevant.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            headline: {
              type: Type.STRING,
              description: 'A sharp 6-10 word atmospheric verdict tailored to the user intent.',
            },
            atmosphericSummary: {
              type: Type.STRING,
              description: '2 concise sentences describing how conditions evolve over the next 24 hours.',
            },
            bestWindow: {
              type: Type.STRING,
              description: 'The optimal time window (e.g., 07:00–11:00) and why.',
            },
            packingEssentials: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '3 to 4 specific gear or clothing recommendations based on temperature, wind, UV, and precipitation.',
            },
            microclimateAlert: {
              type: Type.STRING,
              description: 'Any notable shift (wind gusts, sharp nocturnal drop, high UV, fog, or calm stability) in 1 sentence.',
            },
            activityOutlook: {
              type: Type.STRING,
              description: 'Actionable 1-2 sentence advice directly tailored to the selected activity intent.',
            },
          },
          required: [
            'headline',
            'atmosphericSummary',
            'bestWindow',
            'packingEssentials',
            'microclimateAlert',
            'activityOutlook',
          ],
        },
      },
    });

    const text = (response.text || '').trim();
    if (!text) {
      res.status(502).json({ error: 'Gemini returned an empty forecast briefing.' });
      return;
    }

    const parsed = JSON.parse(text);
    res.json({ briefing: parsed });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Failed to generate AI forecast briefing';
    res.status(500).json({ error: message });
  }
});

// Interactive Destination Weather Q&A
app.post('/api/ai-ask', async (req: Request, res: Response) => {
  try {
    const { weather, question, unit = 'C' } = req.body as {
      weather: Record<string, any>;
      question: string;
      unit?: string;
    };

    if (!weather?.destination || !question?.trim()) {
      res.status(400).json({ error: 'Destination weather and a question are required.' });
      return;
    }

    const ai = getGeminiClient();
    const promptContext = {
      destination: weather.destination,
      unitPreference: unit === 'F' ? 'Fahrenheit and mph' : 'Celsius and km/h',
      current: weather.current,
      airQuality: weather.airQuality,
      hourly24h: weather.hourly,
      daily7d: weather.daily,
    };

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: `Destination: ${weather.destination.name}, ${weather.destination.country}
User question: "${question.trim()}"
Respond in ${promptContext.unitPreference} using the real meteorological telemetry below. Keep the answer practical, specific, and under 90 words.

Telemetry:
${JSON.stringify(promptContext)}`,
      config: {
        systemInstruction:
          'You are VayuMausam AI. Answer user questions about the active destination forecast strictly using the supplied telemetry. Give direct, actionable timing and numerical guidance without filler.',
      },
    });

    const answer = (response.text || '').trim();
    if (!answer) {
      res.status(502).json({ error: 'Gemini returned an empty answer.' });
      return;
    }

    res.json({ answer });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Failed to answer forecast question';
    res.status(500).json({ error: message });
  }
});

// Multi-Destination AI Comparison Verdict
app.post('/api/ai-compare', async (req: Request, res: Response) => {
  try {
    const { destinations, focus = 'clear weather and outdoor comfort', unit = 'C' } = req.body as {
      destinations: Array<Record<string, any>>;
      focus?: string;
      unit?: string;
    };

    if (!Array.isArray(destinations) || destinations.length < 2) {
      res.status(400).json({ error: 'At least 2 destinations are required for comparison.' });
      return;
    }

    const ai = getGeminiClient();
    const compact = destinations.map((d) => ({
      name: d.destination.name,
      country: d.destination.country,
      current: d.current,
      airQuality: d.airQuality,
      next3Days: Array.isArray(d.daily) ? d.daily.slice(0, 3) : [],
    }));

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: `Compare these destinations for a traveler prioritizing: "${focus}".
Express values in ${unit === 'F' ? 'Fahrenheit and mph' : 'Celsius and km/h'}.

Destinations Telemetry:
${JSON.stringify(compact)}`,
      config: {
        systemInstruction:
          'You are VayuMausam AI. Provide an objective meteorological comparison across the supplied destinations.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            recommendedDestination: { type: Type.STRING },
            verdictHeadline: { type: Type.STRING },
            comparativeAnalysis: { type: Type.STRING },
            destinationHighlights: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  strength: { type: Type.STRING },
                  watchout: { type: Type.STRING },
                },
                required: ['name', 'strength', 'watchout'],
              },
            },
          },
          required: [
            'recommendedDestination',
            'verdictHeadline',
            'comparativeAnalysis',
            'destinationHighlights',
          ],
        },
      },
    });

    const text = (response.text || '').trim();
    if (!text) {
      res.status(502).json({ error: 'Gemini returned an empty comparison.' });
      return;
    }
    res.json({ comparison: JSON.parse(text) });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Failed to compare destinations';
    res.status(500).json({ error: message });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`VayuMausam server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
