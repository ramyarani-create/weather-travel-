import { useEffect, useState } from 'react';
import { RefreshCw, Send } from 'lucide-react';
import type { AIBriefing, ForecastIntent, TempUnit, WeatherPayload } from '../types/weather.ts';

interface AIBriefingPanelProps {
  weather: WeatherPayload;
  unit: TempUnit;
}

const INTENTS: Array<{ id: ForecastIntent; label: string }> = [
  { id: 'travel', label: 'Travel & Transit' },
  { id: 'photography', label: 'Photography' },
  { id: 'outdoor', label: 'Trail & Outdoor' },
  { id: 'commute', label: 'Daily Commute' },
];

export function AIBriefingPanel({ weather, unit }: AIBriefingPanelProps) {
  const [intent, setIntent] = useState<ForecastIntent>('travel');
  const [briefing, setBriefing] = useState<AIBriefing | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [reloadNonce, setReloadNonce] = useState(0);

  const [question, setQuestion] = useState('');
  const [asking, setAsking] = useState(false);
  const [qaHistory, setQaHistory] = useState<Array<{ q: string; a: string }>>([]);
  const [qaError, setQaError] = useState<string | null>(null);

  useEffect(() => {
    setQaHistory([]);
    setQaError(null);
  }, [weather.destination.id]);

  useEffect(() => {
    let cancelled = false;
    const fetchBriefing = async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch('/api/ai-forecast', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ weather, intent, unit }),
        });
        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || 'Unable to generate AI briefing');
        }
        if (!cancelled) {
          setBriefing(data.briefing);
        }
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : 'AI briefing unavailable');
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    fetchBriefing();
    return () => {
      cancelled = true;
    };
  }, [weather.destination.id, weather.fetchedAt, intent, unit, reloadNonce]);

  const handleAsk = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = question.trim();
    if (!trimmed || asking) return;
    setAsking(true);
    setQaError(null);
    try {
      const res = await fetch('/api/ai-ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ weather, question: trimmed, unit }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to answer question');
      }
      setQaHistory((prev) => [{ q: trimmed, a: data.answer }, ...prev].slice(0, 3));
      setQuestion('');
    } catch (err) {
      setQaError(err instanceof Error ? err.message : 'Unable to answer right now');
    } finally {
      setAsking(false);
    }
  };

  return (
    <div className="glass-panel flex flex-col justify-between rounded-2xl p-6">
      <div>
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#7dd3fc]/10 pb-4">
          <div>
            <h2 className="text-base font-semibold tracking-tight text-slate-100">
              VayuMausam AI Briefing
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Dynamic atmospheric guidance tailored to your activity
            </p>
          </div>
          <button
            type="button"
            onClick={() => setReloadNonce((n) => n + 1)}
            disabled={loading}
            aria-label="Regenerate AI briefing"
            className="rounded-lg border border-[#7dd3fc]/15 bg-[#7dd3fc]/5 p-2 text-slate-300 hover:border-[#7dd3fc]/35 hover:text-[#7dd3fc] disabled:opacity-50 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7dd3fc]"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* Intent Selector Tabs */}
        <div className="mt-4 flex flex-wrap gap-1.5">
          {INTENTS.map((item) => {
            const active = item.id === intent;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setIntent(item.id)}
                className={`rounded-lg border px-3 py-1.5 text-xs font-medium whitespace-nowrap shrink-0 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7dd3fc] ${
                  active
                    ? 'border-[#c8a0f0]/40 bg-[#c8a0f0]/15 text-[#c8a0f0]'
                    : 'border-[#7dd3fc]/10 bg-transparent text-slate-400 hover:border-[#7dd3fc]/25 hover:text-slate-200'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>

        {/* Content Area */}
        <div className="mt-5">
          {loading && (
            <div className="space-y-3 py-2" aria-live="polite">
              <div className="h-5 w-3/4 animate-pulse rounded bg-[#7dd3fc]/12" />
              <div className="h-4 w-full animate-pulse rounded bg-slate-700/35" />
              <div className="h-4 w-5/6 animate-pulse rounded bg-slate-700/35" />
              <div className="mt-4 grid grid-cols-2 gap-4 border-t border-[#7dd3fc]/10 pt-4">
                <div className="h-12 animate-pulse rounded bg-slate-700/25" />
                <div className="h-12 animate-pulse rounded bg-slate-700/25" />
              </div>
            </div>
          )}

          {!loading && error && (
            <div className="rounded-xl border border-rose-400/25 bg-rose-500/10 p-4 text-xs text-rose-200">
              <p className="font-medium text-rose-100">AI Briefing Unavailable</p>
              <p className="mt-1 text-rose-200/80">{error}</p>
              <button
                type="button"
                onClick={() => setReloadNonce((n) => n + 1)}
                className="mt-3 rounded-lg border border-rose-300/30 bg-rose-500/15 px-3 py-1.5 text-xs font-medium text-rose-100 hover:bg-rose-500/25 transition-colors"
              >
                Retry Briefing
              </button>
            </div>
          )}

          {!loading && !error && briefing && (
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-semibold leading-snug text-[#7dd3fc] text-balance">
                  {briefing.headline}
                </h3>
                <p className="mt-1.5 text-sm leading-relaxed text-slate-300">
                  {briefing.atmosphericSummary}
                </p>
              </div>

              <div className="grid gap-4 border-t border-[#7dd3fc]/10 pt-4 sm:grid-cols-2">
                <div>
                  <div className="text-xs font-medium text-slate-400">Optimal Window</div>
                  <p className="mt-1 text-xs leading-relaxed text-slate-200">
                    {briefing.bestWindow}
                  </p>
                </div>
                <div>
                  <div className="text-xs font-medium text-slate-400">Microclimate Watch</div>
                  <p className="mt-1 text-xs leading-relaxed text-slate-200">
                    {briefing.microclimateAlert}
                  </p>
                </div>
              </div>

              <div className="border-t border-[#7dd3fc]/10 pt-4">
                <div className="text-xs font-medium text-slate-400">Activity Guidance</div>
                <p className="mt-1 text-xs leading-relaxed text-slate-200">
                  {briefing.activityOutlook}
                </p>
              </div>

              <div className="border-t border-[#7dd3fc]/10 pt-4">
                <div className="text-xs font-medium text-slate-400">Recommended Kit</div>
                <p className="mt-1 text-xs leading-relaxed text-slate-300">
                  {briefing.packingEssentials.join(' · ')}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Interactive Forecast Q&A */}
      <div className="mt-5 border-t border-[#7dd3fc]/10 pt-4">
        <form onSubmit={handleAsk} className="flex items-center gap-2">
          <input
            type="text"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder={`Ask about ${weather.destination.name}'s forecast...`}
            className="glass-interactive w-full rounded-lg border border-[#7dd3fc]/15 bg-[#0a0e1a]/55 px-3.5 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:border-[#7dd3fc]/45 focus:outline-none"
          />
          <button
            type="submit"
            disabled={asking || !question.trim()}
            aria-label="Send forecast question"
            className="glass-interactive flex items-center gap-1.5 rounded-lg border border-[#7dd3fc]/25 bg-[#7dd3fc]/12 px-3.5 py-2 text-xs font-medium text-[#7dd3fc] hover:bg-[#7dd3fc]/22 disabled:opacity-45 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7dd3fc]"
          >
            <Send className="h-3.5 w-3.5" aria-hidden="true" />
            <span>{asking ? 'Asking...' : 'Ask'}</span>
          </button>
        </form>

        {qaError && <p className="mt-2 text-xs text-rose-300">{qaError}</p>}

        {qaHistory.length > 0 && (
          <div className="mt-3 space-y-2.5">
            {qaHistory.map((item, idx) => (
              <div key={idx} className="border-t border-[#7dd3fc]/8 pt-2.5 text-xs">
                <div className="font-medium text-[#c8a0f0]">{item.q}</div>
                <p className="mt-1 leading-relaxed text-slate-300">{item.a}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
