import type { WeatherMeta } from '../utils/weatherCodes.ts';

interface WeatherGlyphProps {
  glyph: WeatherMeta['glyph'];
  className?: string;
}

export function WeatherGlyph({ glyph, className = 'w-8 h-8' }: WeatherGlyphProps) {
  switch (glyph) {
    case 'sun':
      return (
        <svg viewBox="0 0 40 40" fill="none" className={className} aria-hidden="true">
          <circle cx="20" cy="20" r="8" stroke="#7dd3fc" strokeWidth="2" fill="rgba(125,211,252,0.16)" />
          <path
            d="M20 5V8M20 32V35M5 20H8M32 20H35M9.4 9.4L11.5 11.5M28.5 28.5L30.6 30.6M30.6 9.4L28.5 11.5M11.5 28.5L9.4 30.6"
            stroke="#7dd3fc"
            strokeWidth="1.75"
            strokeLinecap="round"
          />
        </svg>
      );
    case 'moon':
      return (
        <svg viewBox="0 0 40 40" fill="none" className={className} aria-hidden="true">
          <path
            d="M27.5 24.5A10.5 10.5 0 0 1 15.5 12.5a10.4 10.4 0 0 1 .9-4.3A11 11 0 1 0 31.8 23.6a10.4 10.4 0 0 1-4.3.9Z"
            stroke="#c8a0f0"
            strokeWidth="1.85"
            fill="rgba(200,160,240,0.14)"
            strokeLinejoin="round"
          />
          <circle cx="29" cy="11" r="1.2" fill="#7dd3fc" />
        </svg>
      );
    case 'partly-sun':
      return (
        <svg viewBox="0 0 40 40" fill="none" className={className} aria-hidden="true">
          <circle cx="15" cy="15" r="5.5" stroke="#7dd3fc" strokeWidth="1.75" fill="rgba(125,211,252,0.15)" />
          <path
            d="M15 6.5V8M15 22V23.5M6.5 15H8M22 15H23.5M9 9L10.2 10.2M19.8 19.8L21 21M21 9L19.8 10.2"
            stroke="#7dd3fc"
            strokeWidth="1.5"
            strokeLinecap="round"
          />
          <path
            d="M14 29H28.5a4.5 4.5 0 0 0 .5-8.97A6.5 6.5 0 0 0 16.5 18.5a4.5 4.5 0 0 0-2.5 10.5Z"
            stroke="#e2e8f0"
            strokeWidth="1.75"
            fill="rgba(15,21,36,0.85)"
            strokeLinejoin="round"
          />
        </svg>
      );
    case 'partly-moon':
      return (
        <svg viewBox="0 0 40 40" fill="none" className={className} aria-hidden="true">
          <path
            d="M21 15.5a6 6 0 0 1-6.5-6.5c0-.6.1-1.2.2-1.8A6.5 6.5 0 1 0 22.8 15.3c-.6.1-1.2.2-1.8.2Z"
            stroke="#c8a0f0"
            strokeWidth="1.65"
            fill="rgba(200,160,240,0.14)"
          />
          <path
            d="M14 29.5H28.5a4.5 4.5 0 0 0 .5-8.97A6.5 6.5 0 0 0 16.5 19a4.5 4.5 0 0 0-2.5 10.5Z"
            stroke="#e2e8f0"
            strokeWidth="1.75"
            fill="rgba(15,21,36,0.85)"
            strokeLinejoin="round"
          />
        </svg>
      );
    case 'cloud':
      return (
        <svg viewBox="0 0 40 40" fill="none" className={className} aria-hidden="true">
          <path
            d="M12.5 28.5H28.5a5 5 0 0 0 .5-9.98A7 7 0 0 0 15.6 16.5a5.5 5.5 0 0 0-3.1 12Z"
            stroke="#cbd5e1"
            strokeWidth="1.8"
            fill="rgba(125,211,252,0.08)"
            strokeLinejoin="round"
          />
        </svg>
      );
    case 'fog':
      return (
        <svg viewBox="0 0 40 40" fill="none" className={className} aria-hidden="true">
          <path
            d="M11 22h18M8 26.5h24M12 31h16"
            stroke="#7dd3fc"
            strokeWidth="1.8"
            strokeLinecap="round"
            opacity="0.8"
          />
          <path
            d="M13 18h14.5a4 4 0 0 0 .4-7.98A5.8 5.8 0 0 0 16.4 8.5 4.5 4.5 0 0 0 13 18Z"
            stroke="#cbd5e1"
            strokeWidth="1.7"
            fill="rgba(125,211,252,0.07)"
          />
        </svg>
      );
    case 'rain':
      return (
        <svg viewBox="0 0 40 40" fill="none" className={className} aria-hidden="true">
          <path
            d="M12.5 24H28a4.5 4.5 0 0 0 .5-8.97A6.5 6.5 0 0 0 15.8 13.5 4.8 4.8 0 0 0 12.5 24Z"
            stroke="#e2e8f0"
            strokeWidth="1.75"
            fill="rgba(125,211,252,0.08)"
            strokeLinejoin="round"
          />
          <path
            d="M15 28l-1.5 4M20.5 28l-1.5 5M26 28l-1.5 4"
            stroke="#7dd3fc"
            strokeWidth="1.8"
            strokeLinecap="round"
          />
        </svg>
      );
    case 'snow':
      return (
        <svg viewBox="0 0 40 40" fill="none" className={className} aria-hidden="true">
          <path
            d="M12.5 23.5H28a4.5 4.5 0 0 0 .5-8.97A6.5 6.5 0 0 0 15.8 13a4.8 4.8 0 0 0-3.3 10.5Z"
            stroke="#e2e8f0"
            strokeWidth="1.75"
            fill="rgba(125,211,252,0.1)"
            strokeLinejoin="round"
          />
          <circle cx="15" cy="29" r="1.4" fill="#7dd3fc" />
          <circle cx="20.5" cy="31.5" r="1.4" fill="#e0f2fe" />
          <circle cx="26" cy="29" r="1.4" fill="#7dd3fc" />
        </svg>
      );
    case 'storm':
      return (
        <svg viewBox="0 0 40 40" fill="none" className={className} aria-hidden="true">
          <path
            d="M12.5 23.5H28a4.5 4.5 0 0 0 .5-8.97A6.5 6.5 0 0 0 15.8 13a4.8 4.8 0 0 0-3.3 10.5Z"
            stroke="#e2e8f0"
            strokeWidth="1.75"
            fill="rgba(200,160,240,0.12)"
            strokeLinejoin="round"
          />
          <path
            d="M21 24.5l-3 5h4l-2.5 5"
            stroke="#c8a0f0"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      );
  }
}
