import { useEffect, useRef } from 'react';
import type { WeatherMood } from '../types/weather.ts';

interface AtmosphericCanvasProps {
  mood: WeatherMood;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  alpha: number;
}

export function AtmosphericCanvas({ mood }: AtmosphericCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    let animationId = 0;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    const particleCount =
      mood === 'rain' || mood === 'storm'
        ? 95
        : mood === 'snow'
          ? 70
          : mood === 'clear-night'
            ? 55
            : 28;

    const particles: Particle[] = Array.from({ length: particleCount }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      vx:
        mood === 'rain' || mood === 'storm'
          ? -1.5 - Math.random() * 1.2
          : mood === 'snow'
            ? -0.4 + Math.random() * 0.8
            : (Math.random() - 0.5) * 0.12,
      vy:
        mood === 'rain' || mood === 'storm'
          ? 9 + Math.random() * 6
          : mood === 'snow'
            ? 0.6 + Math.random() * 1.1
            : (Math.random() - 0.5) * 0.1,
      size:
        mood === 'rain' || mood === 'storm'
          ? 12 + Math.random() * 10
          : mood === 'snow'
            ? 1.5 + Math.random() * 2.5
            : 1 + Math.random() * 1.6,
      alpha:
        mood === 'rain' || mood === 'storm'
          ? 0.16 + Math.random() * 0.18
          : mood === 'snow'
            ? 0.25 + Math.random() * 0.35
            : 0.15 + Math.random() * 0.35,
    }));

    let tick = 0;

    const drawFrame = () => {
      tick += 0.008;
      ctx.clearRect(0, 0, width, height);

      // Subtle atmospheric aurora/light field depending on weather mood
      const grad1 = ctx.createRadialGradient(
        width * (0.2 + Math.sin(tick * 0.5) * 0.04),
        height * 0.15,
        0,
        width * 0.25,
        height * 0.15,
        width * 0.55
      );

      if (mood === 'clear-day' || mood === 'partly-cloudy') {
        grad1.addColorStop(0, 'rgba(125, 211, 252, 0.11)');
        grad1.addColorStop(0.55, 'rgba(56, 189, 248, 0.03)');
        grad1.addColorStop(1, 'rgba(10, 14, 26, 0)');
      } else if (mood === 'storm') {
        grad1.addColorStop(0, 'rgba(200, 160, 240, 0.09)');
        grad1.addColorStop(0.6, 'rgba(125, 211, 252, 0.04)');
        grad1.addColorStop(1, 'rgba(10, 14, 26, 0)');
      } else if (mood === 'snow') {
        grad1.addColorStop(0, 'rgba(186, 230, 253, 0.10)');
        grad1.addColorStop(0.6, 'rgba(125, 211, 252, 0.03)');
        grad1.addColorStop(1, 'rgba(10, 14, 26, 0)');
      } else {
        grad1.addColorStop(0, 'rgba(125, 211, 252, 0.08)');
        grad1.addColorStop(0.5, 'rgba(200, 160, 240, 0.04)');
        grad1.addColorStop(1, 'rgba(10, 14, 26, 0)');
      }

      ctx.fillStyle = grad1;
      ctx.fillRect(0, 0, width, height);

      const grad2 = ctx.createRadialGradient(
        width * 0.82,
        height * 0.78,
        0,
        width * 0.82,
        height * 0.78,
        width * 0.5
      );
      grad2.addColorStop(0, 'rgba(200, 160, 240, 0.07)');
      grad2.addColorStop(1, 'rgba(10, 14, 26, 0)');
      ctx.fillStyle = grad2;
      ctx.fillRect(0, 0, width, height);

      for (const p of particles) {
        if (!prefersReducedMotion) {
          p.x += p.vx;
          p.y += p.vy;
          if (mood === 'snow') {
            p.x += Math.sin(tick * 2 + p.y * 0.02) * 0.25;
          }
          if (p.y > height + 20) {
            p.y = -20;
            p.x = Math.random() * width;
          } else if (p.y < -20) {
            p.y = height + 20;
          }
          if (p.x > width + 20) p.x = -20;
          if (p.x < -20) p.x = width + 20;
        }

        if (mood === 'rain' || mood === 'storm') {
          ctx.strokeStyle = `rgba(125, 211, 252, ${p.alpha})`;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x + p.vx * 1.4, p.y + p.size);
          ctx.stroke();
        } else if (mood === 'snow') {
          ctx.fillStyle = `rgba(224, 242, 254, ${p.alpha})`;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.fillStyle =
            mood === 'clear-night'
              ? `rgba(186, 230, 253, ${p.alpha * (0.65 + 0.35 * Math.sin(tick * 3 + p.x))})`
              : `rgba(125, 211, 252, ${p.alpha * 0.45})`;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      if (!prefersReducedMotion) {
        animationId = requestAnimationFrame(drawFrame);
      }
    };

    drawFrame();

    return () => {
      window.removeEventListener('resize', handleResize);
      if (animationId) cancelAnimationFrame(animationId);
    };
  }, [mood]);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-0 h-full w-full"
    />
  );
}
