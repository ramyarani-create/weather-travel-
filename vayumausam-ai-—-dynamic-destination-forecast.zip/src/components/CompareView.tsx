import { useEffect, useState } from 'react';
import { Plus, RefreshCw, X } from 'lucide-react';
import type { AICompareResult, Destination, TempUnit, WeatherPayload } from '../types/weather.ts';
import {
  formatCoordinates,
  formatSpeed,
  formatTemp,
  getWeatherMeta,
} from '../utils/weatherCodes.ts';
import { WeatherGlyph } from './WeatherGlyph.tsx';

interface CompareViewProps {
  pinnedDestinations: Destination[];
  activeWeather: WeatherPayload | null;
  unit: TempUnit;
  onOpenSearch: () => void;
  onRemovePinned: (id: string) => void;
  onSelectDestination: (dest: Destination) => void;
}

export function CompareView({
  pinnedDestinations,
  activeWeather,
  unit,
  onOpenSearch,
  onRemovePinned,
  onSelectDestination,
}: CompareViewProps) {
  const [payloads, setPayloads] = useState<WeatherPayload[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [focus, setFocus] = useState('clear skies, low wind, and comfortable outdoor travel');
  const [aiResult, setAiResult] = useState<AICompareResult | null>(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  const compareTargets = pinnedDestinations.slice(0, 3);

  useEffect(() => {
    let cancelled = false;
    const loadAll = async () => {
      if (compareTargets.length === 0) {
        setPayloads([]);
        return;
      }
      setLoading(true);
      setError(null);
      try {
        const fetched = await Promise.all(
          compareTargets.map(async (dest) => {
            if (activeWeather && activeWeather.destination.id === dest.id) {
              return activeWeather;
            }
            const params = new URLSearchParams({
              id: dest.id,
              name: dest.name,
              region: dest.region || '',
              country: dest.country,
              lat: String(dest.latitude),
              lon: String(dest.longitude),
              timezone: dest.timezone,
            });
            const res = await fetch(`/api/weather?${params.toString()}`);
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || `Failed to load ${dest.name}`);
            return data as WeatherPayload;
          })
        );
        if (!cancelled) setPayloads(fetched);
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : 'Unable to compare destinations');
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    loadAll();
    return () => {
      cancelled = true;
    };
  }, [pinnedDestinations, activeWeather]);

  const runAiCompare = async () => {
    if (payloads.length < 2) return;
    setAiLoading(true);
    setAiError(null);
    try {
      const res = await fetch('/api/ai-compare', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ destinations: payloads, focus, unit }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'AI comparison failed');
      setAiResult(data.comparison);
    } catch (err) {
      setAiError(err instanceof Error ? err.message : 'Comparison failed');
    } finally {
      setAiLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="glass-panel flex flex-wrap items-center justify-between gap-4 rounded-2xl p-6">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-slate-100">
            Destination Comparison
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Compare live conditions across up to 3 pinned destinations side by side
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenSearch}
          className="glass-interactive flex items-center gap-2 rounded-lg border border-[#7dd3fc]/25 bg-[#7dd3fc]/10 px-4 py-2 text-xs font-medium text-[#7dd3fc] hover:bg-[#7dd3fc]/20 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7dd3fc]"
        >
          <Plus className="h-3.5 w-3.5" aria-hidden="true" />
          <span>Pin Another City</span>
        </button>
      </div>

      {error && (
        <div className="glass-panel rounded-2xl border-rose-400/25 p-5 text-sm text-rose-200">
          {error}
        </div>
      )}

      {loading ? (
        <div className="grid gap-6 md:grid-cols-3">
          {[0, 1, 2].map((i) => (
            <div key={i} className="glass-panel h-64 animate-pulse rounded-2xl p-6" />
          ))}
        </div>
      ) : payloads.length === 0 ? (
        <div className="glass-panel rounded-2xl p-10 text-center">
          <p className="text-sm text-slate-300">No destinations pinned yet for comparison.</p>
          <button
            type="button"
            onClick={onOpenSearch}
            className="mt-4 rounded-lg border border-[#7dd3fc]/25 bg-[#7dd3fc]/12 px-4 py-2 text-xs font-medium text-[#7dd3fc] hover:bg-[#7dd3fc]/20"
          >
            Search & Pin Destinations
          </button>
        </div>
      ) : (
        <>
          <div className="grid gap-6 md:grid-cols-3">
            {payloads.map((item) => {
              const meta = getWeatherMeta(item.current.weatherCode, item.current.isDay);
              const today = item.daily[0];
              return (
                <div key={item.destination.id} className="glass-panel flex flex-col justify-between rounded-2xl p-6">
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <button
                          type="button"
                          onClick={() => onSelectDestination(item.destination)}
                          className="text-left text-lg font-semibold text-slate-100 hover:text-[#7dd3fc] transition-colors"
                        >
                          {item.destination.name}
                        </button>
                        <div className="mt-0.5 text-xs text-slate-400">
                          {item.destination.country} ·{' '}
                          <span className="font-mono tabular-nums">
                            {formatCoordinates(item.destination.latitude, item.destination.longitude)}
                          </span>
                        </div>
                      </div>
                      {pinnedDestinations.length > 1 && (
                        <button
                          type="button"
                          onClick={() => onRemovePinned(item.destination.id)}
                          aria-label={`Remove ${item.destination.name} from comparison`}
                          className="rounded-lg p-1.5 text-slate-500 hover:bg-[#7dd3fc]/10 hover:text-slate-200"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      )}
                    </div>

                    <div className="mt-5 flex items-center justify-between">
                      <div>
                        <div className="font-mono text-4xl font-semibold tabular-nums text-slate-100">
                          {formatTemp(item.current.temperatureC, unit)}
                        </div>
                        <div className="mt-1 text-xs text-slate-300">{meta.label}</div>
                      </div>
                      <WeatherGlyph glyph={meta.glyph} className="h-12 w-12" />
                    </div>

                    <div className="mt-5 grid grid-cols-2 gap-y-3 gap-x-4 border-t border-[#7dd3fc]/10 pt-4 text-xs">
                      <div>
                        <div className="text-slate-500">Feels Like</div>
                        <div className="mt-0.5 font-mono tabular-nums text-slate-200">
                          {formatTemp(item.current.apparentTemperatureC, unit)}
                        </div>
                      </div>
                      <div>
                        <div className="text-slate-500">Today Range</div>
                        <div className="mt-0.5 font-mono tabular-nums text-slate-200">
                          {today ? `${formatTemp(today.tempMinC, unit)} / ${formatTemp(today.tempMaxC, unit)}` : '—'}
                        </div>
                      </div>
                      <div>
                        <div className="text-slate-500">Wind</div>
                        <div className="mt-0.5 font-mono tabular-nums text-slate-200">
                          {formatSpeed(item.current.windSpeedKmh, unit)}
                        </div>
                      </div>
                      <div>
                        <div className="text-slate-500">Air Quality</div>
                        <div className="mt-0.5 font-mono tabular-nums text-slate-200">
                          {item.airQuality.usAqi !== null ? `${item.airQuality.usAqi} US AQI` : '—'}
                        </div>
                      </div>
                      <div>
                        <div className="text-slate-500">Humidity</div>
                        <div className="mt-0.5 font-mono tabular-nums text-slate-200">
                          {item.current.humidity}%
                        </div>
                      </div>
                      <div>
                        <div className="text-slate-500">Rain Risk</div>
                        <div className="mt-0.5 font-mono tabular-nums text-slate-200">
                          {today ? `${today.precipitationProbabilityMax}%` : '—'}
                        </div>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => onSelectDestination(item.destination)}
                    className="mt-5 w-full rounded-lg border border-[#7dd3fc]/18 bg-[#7dd3fc]/8 py-2 text-xs font-medium text-[#7dd3fc] hover:bg-[#7dd3fc]/16 transition-colors"
                  >
                    Open Full Forecast
                  </button>
                </div>
              );
            })}
          </div>

          {/* AI Comparative Recommendation */}
          {payloads.length >= 2 && (
            <section className="glass-panel rounded-2xl p-6">
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#7dd3fc]/10 pb-4">
                <div>
                  <h2 className="text-lg font-semibold tracking-tight text-slate-100">
                    VayuMausam AI Comparative Verdict
                  </h2>
                  <p className="mt-0.5 text-xs text-slate-400">
                    Synthesize live telemetry across your pinned destinations to pick the best window
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <input
                    type="text"
                    value={focus}
                    onChange={(e) => setFocus(e.target.value)}
                    aria-label="Comparison priority"
                    className="w-64 rounded-lg border border-[#7dd3fc]/15 bg-[#0a0e1a]/55 px-3 py-1.5 text-xs text-slate-100 focus:border-[#7dd3fc]/45 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={runAiCompare}
                    disabled={aiLoading}
                    className="glass-interactive flex items-center gap-1.5 rounded-lg border border-[#c8a0f0]/35 bg-[#c8a0f0]/15 px-4 py-1.5 text-xs font-medium text-[#c8a0f0] hover:bg-[#c8a0f0]/25 disabled:opacity-50 whitespace-nowrap shrink-0"
                  >
                    <RefreshCw className={`h-3.5 w-3.5 ${aiLoading ? 'animate-spin' : ''}`} />
                    <span>{aiLoading ? 'Analyzing...' : 'Run AI Comparison'}</span>
                  </button>
                </div>
              </div>

              {aiError && (
                <div className="mt-4 rounded-xl border border-rose-400/25 bg-rose-500/10 p-4 text-xs text-rose-200">
                  {aiError}
                </div>
              )}

              {aiResult ? (
                <div className="mt-5 space-y-4">
                  <div>
                    <div className="text-xs font-medium text-[#c8a0f0]">
                      Recommended: {aiResult.recommendedDestination}
                    </div>
                    <h3 className="mt-1 text-lg font-semibold text-[#7dd3fc]">
                      {aiResult.verdictHeadline}
                    </h3>
                    <p className="mt-1.5 text-sm leading-relaxed text-slate-300">
                      {aiResult.comparativeAnalysis}
                    </p>
                  </div>

                  <div className="grid gap-4 border-t border-[#7dd3fc]/10 pt-4 sm:grid-cols-3">
                    {aiResult.destinationHighlights.map((h) => (
                      <div key={h.name} className="space-y-1 text-xs">
                        <div className="font-semibold text-slate-100">{h.name}</div>
                        <p className="text-slate-300">
                          <span className="text-[#7dd3fc]">Advantage: </span>
                          {h.strength}
                        </p>
                        <p className="text-slate-400">
                          <span className="text-[#c8a0f0]">Watchout: </span>
                          {h.watchout}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <p className="mt-4 text-xs text-slate-400">
                  Enter your trip priority above and click Run AI Comparison for a tailored multi-city forecast verdict.
                </p>
              )}
            </section>
          )}
        </>
      )}
    </div>
  );
}
