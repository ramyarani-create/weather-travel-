import { formatLocalTimeFromIso } from '../utils/weatherCodes.ts';

interface SolarArcProps {
  sunriseIso: string;
  sunsetIso: string;
  currentIso: string;
}

function toMinutes(iso: string): number {
  const timePart = iso.split('T')[1] || '12:00';
  const [h, m] = timePart.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

export function SolarArc({ sunriseIso, sunsetIso, currentIso }: SolarArcProps) {
  const sunriseMin = toMinutes(sunriseIso);
  const sunsetMin = toMinutes(sunsetIso);
  const currentMin = toMinutes(currentIso);

  const dayDuration = Math.max(sunsetMin - sunriseMin, 1);
  const rawProgress = (currentMin - sunriseMin) / dayDuration;
  const clamped = Math.max(0, Math.min(1, rawProgress));
  const isDaylight = rawProgress >= 0 && rawProgress <= 1;

  // Semi-circle arc geometry: M 14 74 A 66 66 0 0 1 146 74
  const cx = 80;
  const cy = 74;
  const r = 64;
  const angle = Math.PI * (1 - clamped);
  const sunX = cx + r * Math.cos(angle);
  const sunY = cy - r * Math.sin(angle);

  const durationHrs = Math.floor(dayDuration / 60);
  const durationMins = dayDuration % 60;

  return (
    <div className="flex flex-col justify-between">
      <div className="flex items-baseline justify-between">
        <span className="text-xs font-medium text-slate-400">Solar Cycle</span>
        <span className="font-mono text-xs tabular-nums text-slate-400">
          {durationHrs}h {durationMins}m daylight
        </span>
      </div>

      <div className="my-2 flex items-center justify-center">
        <svg viewBox="0 0 160 88" className="w-full max-w-[200px]" aria-label="Solar horizon arc">
          <defs>
            <linearGradient id="solarArcGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#7dd3fc" stopOpacity="0.3" />
              <stop offset="50%" stopColor="#7dd3fc" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#c8a0f0" stopOpacity="0.6" />
            </linearGradient>
          </defs>
          {/* Horizon baseline */}
          <line x1="8" y1={cy} x2="152" y2={cy} stroke="rgba(125, 211, 252, 0.16)" strokeWidth="1" />
          {/* Background dashed track */}
          <path
            d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
            fill="none"
            stroke="rgba(148, 163, 184, 0.2)"
            strokeWidth="1.5"
            strokeDasharray="3 3"
          />
          {/* Active illuminated path */}
          {isDaylight && (
            <path
              d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${sunX} ${sunY}`}
              fill="none"
              stroke="url(#solarArcGrad)"
              strokeWidth="2.2"
              strokeLinecap="round"
            />
          )}
          {/* Sun / Moon position marker */}
          {isDaylight ? (
            <g>
              <circle cx={sunX} cy={sunY} r="7" fill="rgba(125, 211, 252, 0.2)" />
              <circle cx={sunX} cy={sunY} r="3.6" fill="#7dd3fc" />
            </g>
          ) : (
            <circle cx={rawProgress < 0 ? cx - r : cx + r} cy={cy} r="3.2" fill="#c8a0f0" opacity="0.7" />
          )}
        </svg>
      </div>

      <div className="flex items-center justify-between text-xs">
        <div>
          <span className="text-slate-500">Sunrise </span>
          <span className="font-mono tabular-nums text-slate-200">
            {formatLocalTimeFromIso(sunriseIso)}
          </span>
        </div>
        <div>
          <span className="text-slate-500">Sunset </span>
          <span className="font-mono tabular-nums text-slate-200">
            {formatLocalTimeFromIso(sunsetIso)}
          </span>
        </div>
      </div>
    </div>
  );
}
