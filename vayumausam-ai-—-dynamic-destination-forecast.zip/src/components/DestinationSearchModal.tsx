import { useEffect, useRef, useState } from 'react';
import { MapPin, Plus, Search, X } from 'lucide-react';
import type { Destination } from '../types/weather.ts';
import { formatCoordinates } from '../utils/weatherCodes.ts';

export const CURATED_DESTINATIONS: Destination[] = [
  {
    id: 'leh-in',
    name: 'Leh',
    region: 'Ladakh',
    country: 'India',
    latitude: 34.1526,
    longitude: 77.5771,
    elevation: 3500,
    timezone: 'Asia/Kolkata',
  },
  {
    id: 'reykjavik-is',
    name: 'Reykjavik',
    region: 'Capital Region',
    country: 'Iceland',
    latitude: 64.1466,
    longitude: -21.9426,
    elevation: 14,
    timezone: 'Atlantic/Reykjavik',
  },
  {
    id: 'kyoto-jp',
    name: 'Kyoto',
    region: 'Kyoto Prefecture',
    country: 'Japan',
    latitude: 35.0116,
    longitude: 135.7681,
    elevation: 50,
    timezone: 'Asia/Tokyo',
  },
  {
    id: 'zurich-ch',
    name: 'Zürich',
    region: 'Zürich',
    country: 'Switzerland',
    latitude: 47.3769,
    longitude: 8.5417,
    elevation: 408,
    timezone: 'Europe/Zurich',
  },
  {
    id: 'mumbai-in',
    name: 'Mumbai',
    region: 'Maharashtra',
    country: 'India',
    latitude: 19.076,
    longitude: 72.8777,
    elevation: 14,
    timezone: 'Asia/Kolkata',
  },
  {
    id: 'ushuaia-ar',
    name: 'Ushuaia',
    region: 'Tierra del Fuego',
    country: 'Argentina',
    latitude: -54.8019,
    longitude: -68.303,
    elevation: 23,
    timezone: 'America/Argentina/Ushuaia',
  },
];

interface DestinationSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectDestination: (dest: Destination) => void;
  pinnedIds: string[];
  onTogglePin: (dest: Destination) => void;
}

export function DestinationSearchModal({
  isOpen,
  onClose,
  onSelectDestination,
  pinnedIds,
  onTogglePin,
}: DestinationSearchModalProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Destination[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    setQuery('');
    setResults([]);
    setError(null);
    const t = setTimeout(() => inputRef.current?.focus(), 40);
    return () => clearTimeout(t);
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  useEffect(() => {
    const trimmed = query.trim();
    if (trimmed.length < 2) {
      setResults([]);
      setLoading(false);
      setError(null);
      return;
    }

    const controller = new AbortController();
    const timer = setTimeout(async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(`/api/geocode?q=${encodeURIComponent(trimmed)}`, {
          signal: controller.signal,
        });
        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || 'Search failed');
        }
        setResults(data.results || []);
      } catch (err) {
        if ((err as Error).name === 'AbortError') return;
        setError(err instanceof Error ? err.message : 'Unable to search destinations');
      } finally {
        setLoading(false);
      }
    }, 260);

    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [query]);

  if (!isOpen) return null;

  const listToRender = query.trim().length >= 2 ? results : CURATED_DESTINATIONS;

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center bg-[#060913]/70 px-4 pt-20 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Search destination forecast"
      onClick={onClose}
    >
      <div
        className="glass-elevated w-full max-w-2xl overflow-hidden rounded-2xl shadow-[0_0_50px_rgba(125,211,252,0.12)]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3 border-b border-[#7dd3fc]/12 px-5 py-4">
          <Search className="h-4 w-4 shrink-0 text-[#7dd3fc]" aria-hidden="true" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search any city, mountain pass, or coastal town..."
            className="w-full bg-transparent text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none"
          />
          <button
            type="button"
            onClick={onClose}
            aria-label="Close destination search"
            className="rounded-lg p-1.5 text-slate-400 hover:bg-[#7dd3fc]/10 hover:text-slate-100 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7dd3fc]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="max-h-[400px] overflow-y-auto px-3 py-3">
          <div className="px-2 pb-2 text-xs font-medium text-slate-400">
            {query.trim().length >= 2
              ? loading
                ? 'Searching global stations...'
                : `${results.length} matching destinations`
              : 'Featured atmospheric destinations'}
          </div>

          {error && (
            <div className="mx-2 my-2 rounded-lg border border-rose-400/25 bg-rose-500/10 px-4 py-3 text-xs text-rose-200">
              {error}
            </div>
          )}

          {!loading && !error && query.trim().length >= 2 && results.length === 0 && (
            <div className="px-3 py-8 text-center text-sm text-slate-400">
              No destinations matched "{query.trim()}". Try a nearby major city or region.
            </div>
          )}

          <div className="divide-y divide-[#7dd3fc]/8">
            {listToRender.map((dest) => {
              const isPinned = pinnedIds.includes(dest.id);
              return (
                <div
                  key={dest.id}
                  className="flex items-center justify-between gap-4 rounded-xl px-3 py-2.5 hover:bg-[#7dd3fc]/8 transition-colors"
                >
                  <button
                    type="button"
                    onClick={() => {
                      onSelectDestination(dest);
                      onClose();
                    }}
                    className="flex min-w-0 flex-1 items-center gap-3 text-left focus-visible:outline-none"
                  >
                    <MapPin className="h-4 w-4 shrink-0 text-[#7dd3fc]/70" aria-hidden="true" />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-medium text-slate-100">
                        {dest.name}
                        {dest.region ? `, ${dest.region}` : ''}
                      </div>
                      <div className="truncate text-xs text-slate-400">
                        <span>{dest.country}</span>
                        <span aria-hidden="true"> · </span>
                        <span className="font-mono tabular-nums">
                          {formatCoordinates(dest.latitude, dest.longitude)}
                        </span>
                        {typeof dest.elevation === 'number' && (
                          <>
                            <span aria-hidden="true"> · </span>
                            <span className="font-mono tabular-nums">{Math.round(dest.elevation)} m</span>
                          </>
                        )}
                      </div>
                    </div>
                  </button>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => onTogglePin(dest)}
                      className={`rounded-lg border px-2.5 py-1.5 text-xs font-medium whitespace-nowrap transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7dd3fc] ${
                        isPinned
                          ? 'border-[#c8a0f0]/40 bg-[#c8a0f0]/15 text-[#c8a0f0]'
                          : 'border-[#7dd3fc]/15 bg-[#7dd3fc]/5 text-slate-300 hover:border-[#7dd3fc]/35 hover:text-[#7dd3fc]'
                      }`}
                    >
                      {isPinned ? 'Pinned' : (
                        <span className="inline-flex items-center gap-1">
                          <Plus className="h-3 w-3" aria-hidden="true" />
                          Pin
                        </span>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
