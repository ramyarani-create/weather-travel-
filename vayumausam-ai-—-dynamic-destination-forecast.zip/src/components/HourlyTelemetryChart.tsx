import { useMemo, useState } from 'react';
import type { HourlyPoint, TempUnit } from '../types/weather.ts';
import { convertTempValue, formatLocalTimeFromIso, formatSpeed, formatTemp, getWeatherMeta } from '../utils/weatherCodes.ts';
import { WeatherGlyph } from './WeatherGlyph.tsx';

type ChartMetric = 'temp' | 'precip' | 'wind' | 'uv';

interface HourlyTelemetryChartProps {
  hourly: HourlyPoint[];
  unit: TempUnit;
}

function buildSmoothPath(points: Array<{ x: number; y: number }>): string {
  if (points.length === 0) return '';
  if (points.length === 1) return `M ${points[0].x} ${points[0].y}`;
  let d = `M ${points[0].x.toFixed(1)} ${points[0].y.toFixed(1)}`;
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[i];
    const p1 = points[i + 1];
    const midX = ((p0.x + p1.x) / 2).toFixed(1);
    d += ` C ${midX} ${p0.y.toFixed(1)}, ${midX} ${p1.y.toFixed(1)}, ${p1.x.toFixed(1)} ${p1.y.toFixed(1)}`;
  }
  return d;
}

export function HourlyTelemetryChart({ hourly, unit }: HourlyTelemetryChartProps) {
  const [metric, setMetric] = useState<ChartMetric>('temp');
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);

  const slice = useMemo(() => hourly.slice(0, 24), [hourly]);

  const width = 880;
  const height = 220;
  const padX = 28;
  const padTop = 26;
  const padBottom = 34;
  const plotW = width - padX * 2;
  const plotH = height - padTop - padBottom;

  const { primaryPts, secondaryPts, minLabel, maxLabel } = useMemo(() => {
    if (slice.length === 0) {
      return { primaryPts: [], secondaryPts: [], minLabel: '', maxLabel: '' };
    }

    const getPrimary = (p: HourlyPoint): number => {
      if (metric === 'temp') return convertTempValue(p.temperatureC, unit);
      if (metric === 'precip') return p.precipitationProbability;
      if (metric === 'wind') return unit === 'F' ? p.windSpeedKmh * 0.621371 : p.windSpeedKmh;
      return p.uvIndex;
    };

    const getSecondary = (p: HourlyPoint): number => {
      if (metric === 'temp') return convertTempValue(p.apparentTemperatureC, unit);
      if (metric === 'precip') return p.humidity;
      if (metric === 'wind') return unit === 'F' ? p.windGustsKmh * 0.621371 : p.windGustsKmh;
      return p.cloudCover / 10; // scaled 0-10 to match UV range nicely
    };

    const primaryVals = slice.map(getPrimary);
    const secondaryVals = slice.map(getSecondary);
    const combined = [...primaryVals, ...secondaryVals];

    let minVal = Math.min(...combined);
    let maxVal = Math.max(...combined);

    if (metric === 'precip') {
      minVal = 0;
      maxVal = 100;
    } else if (metric === 'uv') {
      minVal = 0;
      maxVal = Math.max(10, Math.ceil(maxVal));
    } else {
      const span = Math.max(4, maxVal - minVal);
      minVal = Math.floor(minVal - span * 0.15);
      maxVal = Math.ceil(maxVal + span * 0.15);
    }

    const range = Math.max(1, maxVal - minVal);

    const toCoords = (vals: number[]) =>
      vals.map((val, i) => ({
        x: padX + (i / Math.max(1, slice.length - 1)) * plotW,
        y: padTop + (1 - (val - minVal) / range) * plotH,
      }));

    const unitSuffix =
      metric === 'temp'
        ? `°${unit}`
        : metric === 'precip'
          ? '%'
          : metric === 'wind'
            ? unit === 'F'
              ? ' mph'
              : ' km/h'
            : ' UV';

    return {
      primaryPts: toCoords(primaryVals),
      secondaryPts: toCoords(secondaryVals),
      minLabel: `${Math.round(minVal)}${unitSuffix}`,
      maxLabel: `${Math.round(maxVal)}${unitSuffix}`,
    };
  }, [slice, metric, unit, plotW, plotH]);

  const activeIdx = hoverIdx !== null ? hoverIdx : 0;
  const activePoint = slice[activeIdx];
  const primaryPath = buildSmoothPath(primaryPts);
  const secondaryPath = buildSmoothPath(secondaryPts);
  const areaPath =
    primaryPts.length > 1
      ? `${primaryPath} L ${primaryPts[primaryPts.length - 1].x.toFixed(1)} ${height - padBottom} L ${primaryPts[0].x.toFixed(1)} ${height - padBottom} Z`
      : '';

  const metricTabs: Array<{ id: ChartMetric; label: string; legendA: string; legendB: string }> = [
    { id: 'temp', label: 'Temperature', legendA: 'Actual Temp', legendB: 'Feels Like' },
    { id: 'precip', label: 'Precipitation', legendA: 'Rain Prob %', legendB: 'Humidity %' },
    { id: 'wind', label: 'Wind & Gusts', legendA: 'Sustained', legendB: 'Gusts' },
    { id: 'uv', label: 'UV & Cloud', legendA: 'UV Index', legendB: 'Cloud Cover' },
  ];

  const currentTab = metricTabs.find((t) => t.id === metric) || metricTabs[0];

  return (
    <section id="hourly" className="glass-panel rounded-2xl p-6">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#7dd3fc]/10 pb-4">
        <div>
          <h2 className="text-lg font-semibold tracking-tight text-slate-100">
            24-Hour Atmospheric Trajectory
          </h2>
          <p className="mt-0.5 text-xs text-slate-400">
            Hover across the timeline to inspect hourly telemetry shifts
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1 rounded-xl border border-[#7dd3fc]/12 bg-[#0a0e1a]/55 p-1">
          {metricTabs.map((tab) => {
            const active = tab.id === metric;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setMetric(tab.id)}
                className={`rounded-lg px-3 py-1.5 text-xs font-medium whitespace-nowrap shrink-0 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7dd3fc] ${
                  active
                    ? 'bg-[#7dd3fc]/18 text-[#7dd3fc]'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Scrub Readout + Legend */}
      {activePoint && (
        <div className="mt-4 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-4 text-xs">
            <span className="font-mono font-medium tabular-nums text-[#7dd3fc]">
              {formatLocalTimeFromIso(activePoint.time)}
            </span>
            <span className="text-slate-200 font-medium">
              {getWeatherMeta(activePoint.weatherCode, activePoint.isDay).label}
            </span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className="font-mono tabular-nums text-slate-300">
              {formatTemp(activePoint.temperatureC, unit)} (Feels {formatTemp(activePoint.apparentTemperatureC, unit)})
            </span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className="font-mono tabular-nums text-slate-300">
              Rain {activePoint.precipitationProbability}%
            </span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className="font-mono tabular-nums text-slate-300">
              Wind {formatSpeed(activePoint.windSpeedKmh, unit)}
            </span>
          </div>

          <div className="flex items-center gap-4 text-xs text-slate-400">
            <span className="inline-flex items-center gap-1.5">
              <span className="h-0.5 w-4 bg-[#7dd3fc]" aria-hidden="true" />
              {currentTab.legendA}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="h-0.5 w-4 border-t border-dashed border-[#c8a0f0]" aria-hidden="true" />
              {currentTab.legendB}
            </span>
          </div>
        </div>
      )}

      {/* Precision SVG Curve */}
      <div className="relative mt-3 w-full">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="h-52 w-full overflow-visible select-none"
          onMouseLeave={() => setHoverIdx(null)}
        >
          <defs>
            <linearGradient id="glacierAreaGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#7dd3fc" stopOpacity="0.24" />
              <stop offset="100%" stopColor="#7dd3fc" stopOpacity="0" />
            </linearGradient>
          </defs>

          {/* Horizontal reference hairlines */}
          {[0.25, 0.5, 0.75, 1].map((ratio) => {
            const y = padTop + ratio * plotH;
            return (
              <line
                key={ratio}
                x1={padX}
                y1={y}
                x2={width - padX}
                y2={y}
                stroke="rgba(125, 211, 252, 0.08)"
                strokeWidth="1"
              />
            );
          })}

          <text x={padX} y={padTop - 8} fill="#64748b" fontSize="10" fontFamily="JetBrains Mono">
            {maxLabel}
          </text>
          <text x={padX} y={height - padBottom - 5} fill="#64748b" fontSize="10" fontFamily="JetBrains Mono">
            {minLabel}
          </text>

          {/* Area Fill */}
          {areaPath && <path d={areaPath} fill="url(#glacierAreaGrad)" />}

          {/* Secondary Dashed Curve */}
          {secondaryPath && (
            <path
              d={secondaryPath}
              fill="none"
              stroke="#c8a0f0"
              strokeWidth="1.6"
              strokeDasharray="4 4"
              opacity="0.85"
            />
          )}

          {/* Primary Luminous Curve */}
          {primaryPath && (
            <path
              d={primaryPath}
              fill="none"
              stroke="#7dd3fc"
              strokeWidth="2.4"
              strokeLinecap="round"
            />
          )}

          {/* Crosshair & Active Point */}
          {primaryPts[activeIdx] && (
            <g>
              <line
                x1={primaryPts[activeIdx].x}
                y1={padTop}
                x2={primaryPts[activeIdx].x}
                y2={height - padBottom}
                stroke="rgba(125, 211, 252, 0.35)"
                strokeWidth="1"
                strokeDasharray="3 3"
              />
              {secondaryPts[activeIdx] && (
                <circle
                  cx={secondaryPts[activeIdx].x}
                  cy={secondaryPts[activeIdx].y}
                  r="3.5"
                  fill="#0a0e1a"
                  stroke="#c8a0f0"
                  strokeWidth="2"
                />
              )}
              <circle
                cx={primaryPts[activeIdx].x}
                cy={primaryPts[activeIdx].y}
                r="7"
                fill="rgba(125, 211, 252, 0.22)"
              />
              <circle
                cx={primaryPts[activeIdx].x}
                cy={primaryPts[activeIdx].y}
                r="4"
                fill="#7dd3fc"
                stroke="#0a0e1a"
                strokeWidth="1.5"
              />
            </g>
          )}

          {/* X-axis hour labels */}
          {slice.map((pt, i) => {
            if (i % 3 !== 0 && i !== slice.length - 1) return null;
            const x = primaryPts[i]?.x ?? 0;
            return (
              <text
                key={pt.time}
                x={x}
                y={height - 10}
                textAnchor="middle"
                fill={i === activeIdx ? '#7dd3fc' : '#64748b'}
                fontSize="10"
                fontFamily="JetBrains Mono"
              >
                {formatLocalTimeFromIso(pt.time)}
              </text>
            );
          })}

          {/* Invisible hit zones for smooth scrubbing */}
          {slice.map((pt, i) => {
            const colW = plotW / Math.max(1, slice.length - 1);
            const x = (primaryPts[i]?.x ?? 0) - colW / 2;
            return (
              <rect
                key={`hit-${pt.time}`}
                x={Math.max(0, x)}
                y={0}
                width={colW}
                height={height}
                fill="transparent"
                className="cursor-crosshair"
                onMouseEnter={() => setHoverIdx(i)}
                onClick={() => setHoverIdx(i)}
              />
            );
          })}
        </svg>
      </div>

      {/* Compact Horizontal Hourly Strip (3-hour intervals, no nested cards) */}
      <div className="mt-4 grid grid-cols-4 gap-2 border-t border-[#7dd3fc]/10 pt-4 sm:grid-cols-8">
        {slice
          .filter((_, idx) => idx % 3 === 0)
          .slice(0, 8)
          .map((pt) => {
            const meta = getWeatherMeta(pt.weatherCode, pt.isDay);
            return (
              <div
                key={`strip-${pt.time}`}
                className="flex flex-col items-center gap-1.5 rounded-xl py-2 text-center hover:bg-[#7dd3fc]/6 transition-colors"
              >
                <span className="font-mono text-xs tabular-nums text-slate-400">
                  {formatLocalTimeFromIso(pt.time)}
                </span>
                <WeatherGlyph glyph={meta.glyph} className="h-6 w-6" />
                <span className="font-mono text-sm font-semibold tabular-nums text-slate-100">
                  {formatTemp(pt.temperatureC, unit)}
                </span>
                <span className="font-mono text-[11px] tabular-nums text-[#7dd3fc]/80">
                  {pt.precipitationProbability}% rain
                </span>
              </div>
            );
          })}
      </div>
    </section>
  );
}
