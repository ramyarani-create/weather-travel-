import { Search } from 'lucide-react';

export type ActiveTab = 'forecast' | 'hourly' | 'weekly' | 'compare';

interface TopBarProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  onOpenSearch: () => void;
}

export function TopBar({ activeTab, onSelectTab, onOpenSearch }: TopBarProps) {
  const navItems: Array<{ id: ActiveTab; label: string }> = [
    { id: 'forecast', label: 'Forecast' },
    { id: 'hourly', label: 'Hourly' },
    { id: 'weekly', label: '7-Day' },
    { id: 'compare', label: 'Compare' },
  ];

  return (
    <header className="sticky top-0 z-30 border-b border-[#7dd3fc]/10 bg-[#0a0e1a]/75 backdrop-blur-xl">
      <div className="mx-auto flex max-w-[1280px] items-center justify-between gap-8 px-6 py-3.5">
        {/* Zone 1: Single-line Brand Wordmark */}
        <button
          type="button"
          onClick={() => onSelectTab('forecast')}
          className="text-lg font-semibold tracking-tight text-slate-100 whitespace-nowrap shrink-0 hover:text-[#7dd3fc] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7dd3fc]/60 rounded"
        >
          VayuMausam
        </button>

        {/* Zone 2: 4 Single-line Navigation Links */}
        <nav aria-label="Primary navigation" className="hidden md:flex items-center gap-7">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectTab(item.id)}
                className={`relative py-1 text-sm font-medium whitespace-nowrap shrink-0 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7dd3fc]/60 rounded ${
                  isActive
                    ? 'text-[#7dd3fc]'
                    : 'text-slate-400 hover:text-slate-100'
                }`}
              >
                {item.label}
                {isActive && (
                  <span
                    aria-hidden="true"
                    className="absolute inset-x-0 -bottom-0.5 h-[1.5px] bg-[#7dd3fc]"
                  />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1 Primary Action */}
        <button
          type="button"
          onClick={onOpenSearch}
          className="glass-interactive flex items-center gap-2 rounded-lg border border-[#7dd3fc]/25 bg-[#7dd3fc]/10 px-4 py-2 text-xs font-medium text-[#7dd3fc] hover:bg-[#7dd3fc]/20 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7dd3fc]"
        >
          <Search className="h-3.5 w-3.5" aria-hidden="true" />
          <span>Search Destination</span>
        </button>
      </div>
    </header>
  );
}
