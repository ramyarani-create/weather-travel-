import type { TempUnit } from '../types/weather.ts';
import { formatSpeed, getCompassLabel } from '../utils/weatherCodes.ts';

interface WindCompassProps {
  speedKmh: number;
  gustsKmh: number;
  directionDeg: number;
  unit: TempUnit;
}

export function WindCompass({ speedKmh, gustsKmh, directionDeg, unit }: WindCompassProps) {
  const cardinal = getCompassLabel(directionDeg);

  return (
    <div className="flex items-center justify-between gap-4">
      <div>
        <div className="text-xs font-medium text-slate-400">Wind Vector</div>
        <div className="mt-1.5 font-mono text-2xl font-semibold tabular-nums text-slate-100">
          {formatSpeed(speedKmh, unit)}
        </div>
        <div className="mt-1 text-xs text-slate-400 tabular-nums">
          <span>{cardinal} ({Math.round(directionDeg)}°)</span>
          <span aria-hidden="true"> · </span>
          <span>Gusts {formatSpeed(gustsKmh, unit)}</span>
        </div>
      </div>

      <svg
        viewBox="0 0 80 80"
        className="h-16 w-16 shrink-0"
        aria-label={`Wind direction ${cardinal} at ${Math.round(directionDeg)} degrees`}
      >
        <circle cx="40" cy="40" r="34" stroke="rgba(125, 211, 252, 0.16)" strokeWidth="1" fill="none" />
        <circle cx="40" cy="40" r="24" stroke="rgba(125, 211, 252, 0.08)" strokeWidth="1" fill="none" />
        <text x="40" y="13" textAnchor="middle" fill="#64748b" fontSize="8" fontFamily="JetBrains Mono">
          N
        </text>
        <text x="68" y="43" textAnchor="middle" fill="#64748b" fontSize="8" fontFamily="JetBrains Mono">
          E
        </text>
        <text x="40" y="72" textAnchor="middle" fill="#64748b" fontSize="8" fontFamily="JetBrains Mono">
          S
        </text>
        <text x="12" y="43" textAnchor="middle" fill="#64748b" fontSize="8" fontFamily="JetBrains Mono">
          W
        </text>
        <g transform={`rotate(${directionDeg} 40 40)`}>
          <line x1="40" y1="54" x2="40" y2="20" stroke="#7dd3fc" strokeWidth="1.8" strokeLinecap="round" />
          <polygon points="40,16 36,24 44,24" fill="#7dd3fc" />
          <circle cx="40" cy="40" r="3" fill="#0a0e1a" stroke="#c8a0f0" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}
