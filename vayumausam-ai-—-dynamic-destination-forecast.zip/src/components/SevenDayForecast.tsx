import { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import type { DailyPoint, TempUnit } from '../types/weather.ts';
import {
  formatDayName,
  formatLocalTimeFromIso,
  formatShortDate,
  formatSpeed,
  formatTemp,
  getUvCategory,
  getWeatherMeta,
} from '../utils/weatherCodes.ts';
import { WeatherGlyph } from './WeatherGlyph.tsx';

interface SevenDayForecastProps {
  daily: DailyPoint[];
  unit: TempUnit;
}

export function SevenDayForecast({ daily, unit }: SevenDayForecastProps) {
  const [expandedDate, setExpandedDate] = useState<string | null>(daily[0]?.date ?? null);

  if (daily.length === 0) return null;

  const globalMin = Math.min(...daily.map((d) => d.tempMinC));
  const globalMax = Math.max(...daily.map((d) => d.tempMaxC));
  const totalSpan = Math.max(1, globalMax - globalMin);

  return (
    <section id="weekly" className="glass-panel rounded-2xl p-6">
      <div className="flex flex-wrap items-baseline justify-between gap-4 border-b border-[#7dd3fc]/10 pb-4">
        <div>
          <h2 className="text-lg font-semibold tracking-tight text-slate-100">
            7-Day Atmospheric Outlook
          </h2>
          <p className="mt-0.5 text-xs text-slate-400">
            Select any day to inspect thermal range, solar timings, and wind peaks
          </p>
        </div>
        <span className="font-mono text-xs tabular-nums text-slate-400">
          Weekly span {formatTemp(globalMin, unit)} to {formatTemp(globalMax, unit)}
        </span>
      </div>

      <div className="mt-2 divide-y divide-[#7dd3fc]/8">
        {daily.map((day, idx) => {
          const meta = getWeatherMeta(day.weatherCode, true);
          const leftPct = ((day.tempMinC - globalMin) / totalSpan) * 100;
          const widthPct = Math.max(8, ((day.tempMaxC - day.tempMinC) / totalSpan) * 100);
          const isExpanded = expandedDate === day.date;

          return (
            <div key={day.date} className="py-1">
              <button
                type="button"
                onClick={() => setExpandedDate(isExpanded ? null : day.date)}
                aria-expanded={isExpanded}
                className="flex w-full items-center gap-4 rounded-xl px-2 py-2.5 text-left hover:bg-[#7dd3fc]/6 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7dd3fc]"
              >
                <div className="w-24 shrink-0">
                  <div className="text-sm font-medium text-slate-100">
                    {formatDayName(day.date, idx)}
                  </div>
                  <div className="text-xs text-slate-400">{formatShortDate(day.date)}</div>
                </div>

                <div className="flex w-36 shrink-0 items-center gap-2.5">
                  <WeatherGlyph glyph={meta.glyph} className="h-6 w-6 shrink-0" />
                  <span className="truncate text-xs text-slate-300">{meta.label}</span>
                </div>

                <div className="hidden w-20 shrink-0 font-mono text-xs tabular-nums text-[#7dd3fc]/85 sm:block">
                  {day.precipitationProbabilityMax}% rain
                </div>

                <div className="flex flex-1 items-center gap-3">
                  <span className="w-9 text-right font-mono text-xs tabular-nums text-slate-400">
                    {formatTemp(day.tempMinC, unit)}
                  </span>
                  <div className="relative h-1.5 flex-1 overflow-hidden rounded-full bg-slate-800/80">
                    <div
                      className="absolute top-0 h-full rounded-full bg-gradient-to-r from-[#7dd3fc]/80 to-[#c8a0f0]/90"
                      style={{ left: `${leftPct}%`, width: `${widthPct}%` }}
                    />
                  </div>
                  <span className="w-9 font-mono text-xs font-medium tabular-nums text-slate-100">
                    {formatTemp(day.tempMaxC, unit)}
                  </span>
                </div>

                <span className="text-slate-500 shrink-0">
                  {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                </span>
              </button>

              {isExpanded && (
                <div className="grid grid-cols-2 gap-4 border-t border-[#7dd3fc]/8 px-3 py-3 text-xs sm:grid-cols-4">
                  <div>
                    <div className="text-slate-500">Feels Like Range</div>
                    <div className="mt-0.5 font-mono tabular-nums text-slate-200">
                      {formatTemp(day.apparentMinC, unit)} – {formatTemp(day.apparentMaxC, unit)}
                    </div>
                  </div>
                  <div>
                    <div className="text-slate-500">Precipitation Volume</div>
                    <div className="mt-0.5 font-mono tabular-nums text-slate-200">
                      {day.precipitationSumMm.toFixed(1)} mm · {day.precipitationProbabilityMax}% prob
                    </div>
                  </div>
                  <div>
                    <div className="text-slate-500">Peak Wind / UV</div>
                    <div className="mt-0.5 font-mono tabular-nums text-slate-200">
                      {formatSpeed(day.windSpeedMaxKmh, unit)} · UV {day.uvIndexMax.toFixed(1)} ({getUvCategory(day.uvIndexMax)})
                    </div>
                  </div>
                  <div>
                    <div className="text-slate-500">Solar Window</div>
                    <div className="mt-0.5 font-mono tabular-nums text-slate-200">
                      {formatLocalTimeFromIso(day.sunrise)} – {formatLocalTimeFromIso(day.sunset)}
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
}
