export type TempUnit = 'C' | 'F';

export type ForecastIntent =
  | 'travel'
  | 'photography'
  | 'outdoor'
  | 'commute';

export type WeatherMood =
  | 'clear-day'
  | 'clear-night'
  | 'partly-cloudy'
  | 'overcast'
  | 'fog'
  | 'rain'
  | 'storm'
  | 'snow';

export interface Destination {
  id: string;
  name: string;
  region?: string;
  country: string;
  latitude: number;
  longitude: number;
  elevation?: number;
  timezone: string;
}

export interface CurrentConditions {
  time: string;
  temperatureC: number;
  apparentTemperatureC: number;
  humidity: number;
  dewPointC: number;
  precipitationMm: number;
  weatherCode: number;
  cloudCover: number;
  pressureHpa: number;
  windSpeedKmh: number;
  windDirectionDeg: number;
  windGustsKmh: number;
  uvIndex: number;
  visibilityKm: number;
  isDay: boolean;
}

export interface HourlyPoint {
  time: string;
  temperatureC: number;
  apparentTemperatureC: number;
  precipitationProbability: number;
  precipitationMm: number;
  weatherCode: number;
  humidity: number;
  cloudCover: number;
  windSpeedKmh: number;
  windGustsKmh: number;
  uvIndex: number;
  isDay: boolean;
}

export interface DailyPoint {
  date: string;
  weatherCode: number;
  tempMaxC: number;
  tempMinC: number;
  apparentMaxC: number;
  apparentMinC: number;
  sunrise: string;
  sunset: string;
  precipitationSumMm: number;
  precipitationProbabilityMax: number;
  windSpeedMaxKmh: number;
  uvIndexMax: number;
}

export interface AirQualityData {
  usAqi: number | null;
  pm25: number | null;
  pm10: number | null;
  ozone: number | null;
  category: string;
}

export interface WeatherPayload {
  destination: Destination;
  utcOffsetSeconds: number;
  current: CurrentConditions;
  hourly: HourlyPoint[];
  daily: DailyPoint[];
  airQuality: AirQualityData;
  fetchedAt: string;
}

export interface AIBriefing {
  headline: string;
  atmosphericSummary: string;
  bestWindow: string;
  packingEssentials: string[];
  microclimateAlert: string;
  activityOutlook: string;
}

export interface AICompareResult {
  recommendedDestination: string;
  verdictHeadline: string;
  comparativeAnalysis: string;
  destinationHighlights: Array<{
    name: string;
    strength: string;
    watchout: string;
  }>;
}
