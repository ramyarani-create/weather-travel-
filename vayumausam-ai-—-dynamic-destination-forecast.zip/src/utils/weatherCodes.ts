import type { TempUnit, WeatherMood } from '../types/weather.ts';

export interface WeatherMeta {
  label: string;
  mood: WeatherMood;
  glyph: 'sun' | 'moon' | 'partly-sun' | 'partly-moon' | 'cloud' | 'fog' | 'rain' | 'snow' | 'storm';
}

export function getWeatherMeta(code: number, isDay = true): WeatherMeta {
  if (code === 0) {
    return {
      label: isDay ? 'Clear Sky' : 'Clear Night',
      mood: isDay ? 'clear-day' : 'clear-night',
      glyph: isDay ? 'sun' : 'moon',
    };
  }
  if (code === 1 || code === 2) {
    return {
      label: code === 1 ? 'Mainly Clear' : 'Partly Cloudy',
      mood: isDay ? 'partly-cloudy' : 'clear-night',
      glyph: isDay ? 'partly-sun' : 'partly-moon',
    };
  }
  if (code === 3) {
    return {
      label: 'Overcast',
      mood: 'overcast',
      glyph: 'cloud',
    };
  }
  if (code === 45 || code === 48) {
    return {
      label: code === 48 ? 'Rime Fog' : 'Mist & Fog',
      mood: 'fog',
      glyph: 'fog',
    };
  }
  if ([51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82].includes(code)) {
    const heavy = [65, 67, 82].includes(code);
    const drizzle = [51, 53, 55, 56, 57].includes(code);
    return {
      label: heavy ? 'Heavy Rain' : drizzle ? 'Light Drizzle' : 'Rain Showers',
      mood: 'rain',
      glyph: 'rain',
    };
  }
  if ([71, 73, 75, 77, 85, 86].includes(code)) {
    const heavy = [75, 86].includes(code);
    return {
      label: heavy ? 'Heavy Snowfall' : 'Snow Showers',
      mood: 'snow',
      glyph: 'snow',
    };
  }
  if ([95, 96, 99].includes(code)) {
    return {
      label: code === 95 ? 'Thunderstorm' : 'Severe Squall',
      mood: 'storm',
      glyph: 'storm',
    };
  }
  return {
    label: 'Variable Cloud',
    mood: 'partly-cloudy',
    glyph: isDay ? 'partly-sun' : 'partly-moon',
  };
}

export function formatTemp(tempC: number, unit: TempUnit, includeSymbol = true): string {
  const value = unit === 'F' ? (tempC * 9) / 5 + 32 : tempC;
  const rounded = Math.round(value);
  return includeSymbol ? `${rounded}°` : `${rounded}`;
}

export function convertTempValue(tempC: number, unit: TempUnit): number {
  return unit === 'F' ? (tempC * 9) / 5 + 32 : tempC;
}

export function formatSpeed(kmh: number, unit: TempUnit): string {
  if (unit === 'F') {
    return `${Math.round(kmh * 0.621371)} mph`;
  }
  return `${Math.round(kmh)} km/h`;
}

export function getCompassLabel(deg: number): string {
  const dirs = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
  const idx = Math.round(((deg % 360) / 22.5)) % 16;
  return dirs[idx];
}

export function formatCoordinates(lat: number, lon: number): string {
  const latStr = `${Math.abs(lat).toFixed(2)}° ${lat >= 0 ? 'N' : 'S'}`;
  const lonStr = `${Math.abs(lon).toFixed(2)}° ${lon >= 0 ? 'E' : 'W'}`;
  return `${latStr}, ${lonStr}`;
}

export function getAqiCategory(aqi: number | null): string {
  if (aqi === null) return 'Unavailable';
  if (aqi <= 50) return 'Good';
  if (aqi <= 100) return 'Moderate';
  if (aqi <= 150) return 'Sensitive Groups';
  if (aqi <= 200) return 'Unhealthy';
  return 'Very Unhealthy';
}

export function getUvCategory(uv: number): string {
  if (uv < 3) return 'Low';
  if (uv < 6) return 'Moderate';
  if (uv < 8) return 'High';
  if (uv < 11) return 'Very High';
  return 'Extreme';
}

export function formatLocalTimeFromIso(isoStr: string): string {
  const parts = isoStr.split('T');
  if (parts.length < 2) return isoStr;
  return parts[1].slice(0, 5);
}

export function formatDayName(dateStr: string, index: number): string {
  if (index === 0) return 'Today';
  if (index === 1) return 'Tomorrow';
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.toLocaleDateString('en-US', { weekday: 'short', timeZone: 'UTC' });
}

export function formatShortDate(dateStr: string): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.toLocaleDateString('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' });
}
