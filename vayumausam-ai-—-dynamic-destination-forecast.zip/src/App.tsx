import { useCallback, useEffect, useMemo, useState } from 'react';
import { Bookmark, RefreshCw, X } from 'lucide-react';
import { AIBriefingPanel } from './components/AIBriefingPanel.tsx';
import { AtmosphericCanvas } from './components/AtmosphericCanvas.tsx';
import { CompareView } from './components/CompareView.tsx';
import {
  CURATED_DESTINATIONS,
  DestinationSearchModal,
} from './components/DestinationSearchModal.tsx';
import { HourlyTelemetryChart } from './components/HourlyTelemetryChart.tsx';
import { SevenDayForecast } from './components/SevenDayForecast.tsx';
import { SolarArc } from './components/SolarArc.tsx';
import { TopBar, type ActiveTab } from './components/TopBar.tsx';
import { WeatherGlyph } from './components/WeatherGlyph.tsx';
import { WindCompass } from './components/WindCompass.tsx';
import type { Destination, TempUnit, WeatherPayload } from './types/weather.ts';
import {
  formatCoordinates,
  formatLocalTimeFromIso,
  formatTemp,
  getUvCategory,
  getWeatherMeta,
} from './utils/weatherCodes.ts';

const STORAGE_PINNED_KEY = 'vayumausam_pinned_destinations_v1';
const STORAGE_ACTIVE_KEY = 'vayumausam_active_destination_v1';
const STORAGE_UNIT_KEY = 'vayumausam_temp_unit_v1';

const DEFAULT_PINNED: Destination[] = CURATED_DESTINATIONS.slice(0, 3);

function loadStoredDestinations(): Destination[] {
  try {
    const raw = localStorage.getItem(STORAGE_PINNED_KEY);
    if (!raw) return DEFAULT_PINNED;
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) return parsed;
  } catch {
    // ignore storage errors
  }
  return DEFAULT_PINNED;
}

function loadStoredActive(pinned: Destination[]): Destination {
  try {
    const raw = localStorage.getItem(STORAGE_ACTIVE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Destination;
      if (parsed && typeof parsed.latitude === 'number') return parsed;
    }
  } catch {
    // ignore
  }
  return pinned[0] || DEFAULT_PINNED[0];
}

export default function App() {
  const [pinned, setPinned] = useState<Destination[]>(() => loadStoredDestinations());
  const [activeDestination, setActiveDestination] = useState<Destination>(() =>
    loadStoredActive(loadStoredDestinations())
  );
  const [unit, setUnit] = useState<TempUnit>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_UNIT_KEY);
      return saved === 'F' ? 'F' : 'C';
    } catch {
      return 'C';
    }
  });

  const [activeTab, setActiveTab] = useState<ActiveTab>('forecast');
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const [weather, setWeather] = useState<WeatherPayload | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshTick, setRefreshTick] = useState(0);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_PINNED_KEY, JSON.stringify(pinned));
    } catch {
      // ignore
    }
  }, [pinned]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_ACTIVE_KEY, JSON.stringify(activeDestination));
    } catch {
      // ignore
    }
  }, [activeDestination]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_UNIT_KEY, unit);
    } catch {
      // ignore
    }
  }, [unit]);

  // Global Cmd/Ctrl + K search shortcut
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Fetch live meteorological telemetry for active destination
  useEffect(() => {
    let cancelled = false;
    const loadWeather = async () => {
      setLoading(true);
      setError(null);
      try {
        const params = new URLSearchParams({
          id: activeDestination.id,
          name: activeDestination.name,
          region: activeDestination.region || '',
          country: activeDestination.country,
          lat: String(activeDestination.latitude),
          lon: String(activeDestination.longitude),
          timezone: activeDestination.timezone || 'auto',
        });
        if (typeof activeDestination.elevation === 'number') {
          params.set('elevation', String(activeDestination.elevation));
        }

        const res = await fetch(`/api/weather?${params.toString()}`);
        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || 'Failed to fetch meteorological telemetry');
        }
        if (!cancelled) {
          setWeather(data as WeatherPayload);
        }
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : 'Unable to load destination forecast');
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    loadWeather();
    return () => {
      cancelled = true;
    };
  }, [activeDestination, refreshTick]);

  const handleTogglePin = useCallback((dest: Destination) => {
    setPinned((prev) => {
      const exists = prev.some((d) => d.id === dest.id);
      if (exists) {
        if (prev.length <= 1) return prev;
        return prev.filter((d) => d.id !== dest.id);
      }
      return [...prev, dest];
    });
  }, []);

  const handleSelectDestination = useCallback((dest: Destination) => {
    setActiveDestination(dest);
    setActiveTab('forecast');
  }, []);

  const handleNavTab = useCallback((tab: ActiveTab) => {
    setActiveTab(tab);
    if (tab === 'hourly' || tab === 'weekly') {
      setTimeout(() => {
        const el = document.getElementById(tab);
        el?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 40);
    } else if (tab === 'forecast') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, []);

  const currentMeta = useMemo(() => {
    if (!weather) {
      return getWeatherMeta(1, true);
    }
    return getWeatherMeta(weather.current.weatherCode, weather.current.isDay);
  }, [weather]);

  const isCurrentPinned = pinned.some((d) => d.id === activeDestination.id);
  const todayDaily = weather?.daily[0];

  return (
    <div className="relative min-h-screen bg-[#0a0e1a] text-slate-100">
      <AtmosphericCanvas mood={currentMeta.mood} />

      <TopBar
        activeTab={activeTab}
        onSelectTab={handleNavTab}
        onOpenSearch={() => setIsSearchOpen(true)}
      />

      <main className="relative z-10 mx-auto max-w-[1280px] px-6 py-6">
        {/* Workspace Toolbar: Pinned Destinations & Unit Control */}
        <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-2">
            {pinned.map((dest) => {
              const isSelected = dest.id === activeDestination.id && activeTab !== 'compare';
              return (
                <div
                  key={dest.id}
                  className={`flex items-center rounded-lg border text-xs font-medium transition-colors ${
                    isSelected
                      ? 'border-[#7dd3fc]/35 bg-[#7dd3fc]/14 text-[#7dd3fc]'
                      : 'border-[#7dd3fc]/10 bg-[#0f1524]/60 text-slate-300 hover:border-[#7dd3fc]/25 hover:text-slate-100'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => handleSelectDestination(dest)}
                    className="px-3 py-1.5 whitespace-nowrap shrink-0 focus-visible:outline-none"
                  >
                    {dest.name}
                  </button>
                  {pinned.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleTogglePin(dest)}
                      aria-label={`Unpin ${dest.name}`}
                      className="pr-2 text-slate-500 hover:text-slate-200 transition-colors"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  )}
                </div>
              );
            })}

            {!isCurrentPinned && (
              <button
                type="button"
                onClick={() => handleTogglePin(activeDestination)}
                className="flex items-center gap-1.5 rounded-lg border border-[#c8a0f0]/30 bg-[#c8a0f0]/10 px-3 py-1.5 text-xs font-medium text-[#c8a0f0] hover:bg-[#c8a0f0]/20 whitespace-nowrap shrink-0 transition-colors"
              >
                <Bookmark className="h-3 w-3" aria-hidden="true" />
                <span>Pin {activeDestination.name}</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-3">
            {/* Mobile compact tab selector */}
            <div className="flex items-center gap-1 rounded-lg border border-[#7dd3fc]/12 bg-[#0f1524]/60 p-0.5 md:hidden">
              {(['forecast', 'compare'] as const).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => handleNavTab(t)}
                  className={`rounded-md px-2.5 py-1 text-xs font-medium capitalize ${
                    activeTab === t ? 'bg-[#7dd3fc]/18 text-[#7dd3fc]' : 'text-slate-400'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>

            <div
              role="group"
              aria-label="Temperature unit"
              className="flex items-center rounded-lg border border-[#7dd3fc]/14 bg-[#0f1524]/60 p-0.5"
            >
              {(['C', 'F'] as const).map((u) => (
                <button
                  key={u}
                  type="button"
                  onClick={() => setUnit(u)}
                  className={`rounded-md px-2.5 py-1 font-mono text-xs font-medium transition-colors ${
                    unit === u
                      ? 'bg-[#7dd3fc]/18 text-[#7dd3fc]'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  °{u}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() => setRefreshTick((t) => t + 1)}
              disabled={loading}
              aria-label="Refresh forecast telemetry"
              className="glass-interactive flex items-center gap-1.5 rounded-lg border border-[#7dd3fc]/14 bg-[#0f1524]/60 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-[#7dd3fc] disabled:opacity-50 whitespace-nowrap shrink-0"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} aria-hidden="true" />
              <span className="hidden sm:inline">Refresh</span>
            </button>
          </div>
        </div>

        {activeTab === 'compare' ? (
          <CompareView
            pinnedDestinations={pinned}
            activeWeather={weather}
            unit={unit}
            onOpenSearch={() => setIsSearchOpen(true)}
            onRemovePinned={(id) => {
              const target = pinned.find((p) => p.id === id);
              if (target) handleTogglePin(target);
            }}
            onSelectDestination={handleSelectDestination}
          />
        ) : (
          <div className="space-y-6">
            {error && (
              <div className="glass-panel flex flex-wrap items-center justify-between gap-4 rounded-2xl border-rose-400/25 p-5 text-sm text-rose-200">
                <div>
                  <div className="font-semibold text-rose-100">Unable to load live telemetry</div>
                  <div className="mt-0.5 text-xs text-rose-200/80">{error}</div>
                </div>
                <button
                  type="button"
                  onClick={() => setRefreshTick((t) => t + 1)}
                  className="rounded-lg border border-rose-300/30 bg-rose-500/15 px-3.5 py-1.5 text-xs font-medium text-rose-100 hover:bg-rose-500/25"
                >
                  Retry
                </button>
              </div>
            )}

            {loading && !weather ? (
              <div className="grid gap-6 lg:grid-cols-12">
                <div className="glass-panel h-[380px] animate-pulse rounded-2xl p-6 lg:col-span-5" />
                <div className="glass-panel h-[380px] animate-pulse rounded-2xl p-6 lg:col-span-7" />
              </div>
            ) : (
              weather && (
                <>
                  {/* Hero Split: Focal Atmospheric Anchor + AI Dynamic Briefing */}
                  <div className="grid items-stretch gap-6 lg:grid-cols-12">
                    {/* Left Column: Current Destination Conditions */}
                    <section className="glass-panel flex flex-col justify-between rounded-2xl p-6 lg:col-span-5">
                      <div>
                        <div className="flex items-start justify-between gap-4">
                          <div>
                            <h1 className="text-3xl font-semibold tracking-tight text-slate-100 text-balance">
                              {weather.destination.name}
                            </h1>
                            <p className="mt-1 text-xs text-slate-400">
                              <span>
                                {weather.destination.region
                                  ? `${weather.destination.region}, `
                                  : ''}
                                {weather.destination.country}
                              </span>
                              <span aria-hidden="true"> · </span>
                              <span className="font-mono tabular-nums">
                                {formatCoordinates(
                                  weather.destination.latitude,
                                  weather.destination.longitude
                                )}
                              </span>
                              {typeof weather.destination.elevation === 'number' && (
                                <>
                                  <span aria-hidden="true"> · </span>
                                  <span className="font-mono tabular-nums">
                                    {Math.round(weather.destination.elevation)} m
                                  </span>
                                </>
                              )}
                            </p>
                          </div>

                          <div className="text-right">
                            <div className="text-xs text-slate-400">Local Time</div>
                            <div className="mt-0.5 font-mono text-sm font-medium tabular-nums text-slate-200">
                              {formatLocalTimeFromIso(weather.current.time)}
                            </div>
                          </div>
                        </div>

                        {/* Dominant Temperature & Condition Glyph */}
                        <div className="mt-8 flex items-center justify-between gap-4">
                          <div>
                            <div className="font-mono text-6xl font-semibold tracking-tight tabular-nums text-slate-100">
                              {formatTemp(weather.current.temperatureC, unit)}
                            </div>
                            <div className="mt-2 text-base font-medium text-[#7dd3fc]">
                              {currentMeta.label}
                            </div>
                            <div className="mt-1 text-xs text-slate-400 tabular-nums">
                              <span>
                                Feels like {formatTemp(weather.current.apparentTemperatureC, unit)}
                              </span>
                              {todayDaily && (
                                <>
                                  <span aria-hidden="true"> · </span>
                                  <span>
                                    H {formatTemp(todayDaily.tempMaxC, unit)} / L{' '}
                                    {formatTemp(todayDaily.tempMinC, unit)}
                                  </span>
                                </>
                              )}
                            </div>
                          </div>

                          <WeatherGlyph glyph={currentMeta.glyph} className="h-24 w-24 shrink-0" />
                        </div>
                      </div>

                      {/* Solar Trajectory Arc inside bottom section */}
                      {todayDaily && (
                        <div className="mt-8 border-t border-[#7dd3fc]/10 pt-5">
                          <SolarArc
                            sunriseIso={todayDaily.sunrise}
                            sunsetIso={todayDaily.sunset}
                            currentIso={weather.current.time}
                          />
                        </div>
                      )}
                    </section>

                    {/* Right Column: VayuMausam AI Briefing */}
                    <div className="lg:col-span-7 flex flex-col">
                      <AIBriefingPanel weather={weather} unit={unit} />
                    </div>
                  </div>

                  {/* Unified Glass Atmospheric Telemetry Matrix (Single Elevation, Hairline Dividers) */}
                  <section
                    aria-label="Atmospheric telemetry details"
                    className="glass-panel grid divide-y divide-[#7dd3fc]/10 rounded-2xl md:grid-cols-4 md:divide-x md:divide-y-0"
                  >
                    <div className="p-5">
                      <WindCompass
                        speedKmh={weather.current.windSpeedKmh}
                        gustsKmh={weather.current.windGustsKmh}
                        directionDeg={weather.current.windDirectionDeg}
                        unit={unit}
                      />
                    </div>

                    <div className="flex flex-col justify-between p-5">
                      <div className="text-xs font-medium text-slate-400">
                        Moisture & Dew Point
                      </div>
                      <div className="mt-1.5 font-mono text-2xl font-semibold tabular-nums text-slate-100">
                        {weather.current.humidity}%
                      </div>
                      <div className="mt-1 text-xs text-slate-400 tabular-nums">
                        <span>Dew point {formatTemp(weather.current.dewPointC, unit)}</span>
                        <span aria-hidden="true"> · </span>
                        <span>Cloud {weather.current.cloudCover}%</span>
                      </div>
                    </div>

                    <div className="flex flex-col justify-between p-5">
                      <div className="text-xs font-medium text-slate-400">
                        Barometer & Visibility
                      </div>
                      <div className="mt-1.5 font-mono text-2xl font-semibold tabular-nums text-slate-100">
                        {Math.round(weather.current.pressureHpa)}{' '}
                        <span className="text-sm font-normal text-slate-400">hPa</span>
                      </div>
                      <div className="mt-1 text-xs text-slate-400 tabular-nums">
                        <span>Visibility {weather.current.visibilityKm} km</span>
                        <span aria-hidden="true"> · </span>
                        <span>Precip {weather.current.precipitationMm.toFixed(1)} mm</span>
                      </div>
                    </div>

                    <div className="flex flex-col justify-between p-5">
                      <div className="text-xs font-medium text-slate-400">
                        Air Quality & Solar UV
                      </div>
                      <div className="mt-1.5 flex items-baseline gap-2">
                        <span className="font-mono text-2xl font-semibold tabular-nums text-slate-100">
                          {weather.airQuality.usAqi !== null ? weather.airQuality.usAqi : '—'}
                        </span>
                        <span className="text-xs font-medium text-[#7dd3fc]">
                          {weather.airQuality.usAqi !== null
                            ? `US AQI · ${weather.airQuality.category}`
                            : 'AQI Unavailable'}
                        </span>
                      </div>
                      <div className="mt-1 text-xs text-slate-400 tabular-nums">
                        <span>
                          UV {weather.current.uvIndex.toFixed(1)} ({getUvCategory(weather.current.uvIndex)})
                        </span>
                        {weather.airQuality.pm25 !== null && (
                          <>
                            <span aria-hidden="true"> · </span>
                            <span>PM2.5 {weather.airQuality.pm25.toFixed(1)} µg/m³</span>
                          </>
                        )}
                      </div>
                    </div>
                  </section>

                  {/* 24-Hour Interactive Trajectory Chart */}
                  <HourlyTelemetryChart hourly={weather.hourly} unit={unit} />

                  {/* 7-Day Atmospheric Outlook */}
                  <SevenDayForecast daily={weather.daily} unit={unit} />
                </>
              )
            )}
          </div>
        )}
      </main>

      <footer className="relative z-10 mx-auto mt-6 max-w-[1280px] border-t border-[#7dd3fc]/10 px-6 py-6 text-xs text-slate-500 flex flex-wrap items-center justify-between gap-4">
        <span>VayuMausam AI · Dynamic Destination Forecast</span>
        <span>Live weather telemetry powered by Open-Meteo · Press ⌘K to switch destination</span>
      </footer>

      <DestinationSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectDestination={handleSelectDestination}
        pinnedIds={pinned.map((d) => d.id)}
        onTogglePin={handleTogglePin}
      />
    </div>
  );
}
